{
  "status": "complete",
  "final_state": "Both deliverables are on disk and were extended after the first submission with the peer-requested status of the optional Phase 3 and with the ancestry analysis.",
  "files": {
    "DELTA.md": "/home/user/projects/npunlock-work/delta/DELTA.md — 445 lines. Classified vendor-vs-upstream delta (54 -shave-* cl::opt objects with .data addresses/defaults/consumer functions; 11 SHAVE passes with registration + factory addresses; 36 SHAVEISD nodes; 41 CPUs; sched/unit/register surface; driver + moviAsm64 deltas; upstream classification in raw/upstream_classification.tsv; negative results; evidence index).",
    "ANNOTATED_DELTA.md": "/home/user/projects/npunlock-work/delta/ANNOTATED_DELTA.md — 926 lines. Part I: annotated excerpts with descriptive renames + rules R1-R21 + moviAsm64/hardware cross-check. Part II: D1 target/DataLayout/ABI, D2 ISel coverage, D3 scheduling/latency/packets, D4 pass pipeline, D5 asm printer/bundling/predicates, D6 ranked 'we must implement X' list, D7 Hexagon ancestry (packetizer belongs in the assembler, not the backend).",
    "evidence_and_tools": "delta/raw/{opt_xrefs.json, upstream_classification.tsv, flagbuilder_1800dbac0.c, postsched_1800e8e80.c, shave_ids.txt, upstream_patterns.txt} and delta/tools/{strva.py, xref.py, optxref2.py, lines2fn.py}."
  },
  "changes_since_first_yield": [
    "Added ANNOTATED_DELTA.md section D7 (Hexagon ancestry) verified against pristine upstream: VLIWPacketizerList/DFAPacketizer are upstream, Hexagon's packetizer has isSoloInstruction/isPureSlot0/'slot1-store-slot0-load', but the vendor compiler has NO packetizer pass — SHAVE moved pipe legality into moviAsm64 (8x 'unit is used more than once in the same pipe', .64/.128 blocks, SLOT_ALL, NOP compression). Actionable: do not port the DFA packetizer; produce bundles in the backend and validate/pack in the assembler.",
    "Two peer-requested confirmations sent to AsmEncodingRE: the exact packet-separator literal '            || ' (12 spaces + '||' + space, moviCompile64.ascii.txt:88065, inside the SHAVE asm-printer string blob) and the -no6thSlotCompression correction (absent from both vendor DLLs; vendor assembler argv is `--noSPrefixing --cv <cpu>` + -Wa, passthrough).",
    "Phase 3 (vanilla LLVM build) completed by peer AsmEncodingRE (/tmp/llvm14-vanilla/llvm/build/bin/llc); I judged Ghidra cross-build function matching low-yield versus the already-pinned evidence and used the pristine sources for the ancestry check instead. No build was run by me in llvm-14."
  ],
  "top10_rules_ranked_for_general_C": [
    {
      "rank": 1,
      "rule": "CMU compare writes a FLAG named by its operand register; BRU.BRA branches on that flag (never materialise 0/1, never XOR)",
      "confidence": "[H] gold CMU.CMZ.I32 i5 @0x50 -> BRU.BRA i5,0xb7; [S] SHAVEISD::SETCC + 60 SHAVE_SETCC_*_Myr4 nodes"
    },
    {
      "rank": 2,
      "rule": "Load latency = 6 cycles enforced as a scheduling distance (default latency 6 for unstaged opcodes; hw may force 8)",
      "confidence": "[V] FUN_180138bd0 (returns 6), FUN_180145fd0 (MFI+0x190), FUN_1800e8e80 (trace bound); [H] K=6 pass / K=4,5 fail"
    },
    {
      "rank": 3,
      "rule": "Pipe = 1 op per unit over BRU CMU IAU LSU0 LSU1 PEU SAU VAU, <=128 bits, one text line with '            || ' separators",
      "confidence": "[V] moviAsm64 2557-2641, 2553-2568, 88065; [H] gold 1-3 ops/pipe"
    },
    {
      "rank": 4,
      "rule": "LSU discipline: loads LSU0 / stores LSU1, no same-unit reuse in a pipe window, aliased store->load >=1 cycle",
      "confidence": "[V] moviAsm64 2616-2617 + FUN_1800e8e80; [H] LSU0+LSU0 => garbage"
    },
    {
      "rank": 5,
      "rule": "Branch delay = 6 executable slots after any taken branch (B_STATE-tracked)",
      "confidence": "[V] FUN_1801387b0 (MFI+0x18c); [H] marker experiment"
    },
    {
      "rank": 6,
      "rule": "Constants: LDIL->LSU0 + LDIH->LSU1 in the SAME pipe when shave-has-LSU1-fu, else two pipes",
      "confidence": "[V] FUN_180098410; [H] LDIL/LDIH byte forms; vendor abort stub"
    },
    {
      "rank": 7,
      "rule": "Calls/frames: i18 arg, i30 ret, ADJCALLSTACKDOWN/UP, SHAVEISD::CALL/RET_FLAG/DYNALLOC; varargs unproven",
      "confidence": "[V] SHAVE opcode-name array 82700-83000 + DAG node strings"
    },
    {
      "rank": 8,
      "rule": "Arithmetic: i32 native ALU; divide SAU-only; f16/f32 native, f64 soft-float; i64 as explicit pairs with libcalls",
      "confidence": "[S] builtin families (VAU 744/SAU 306/CMU 294/IAU 54/LSU 42/BRU 4), I64_* nodes; [V] -D__SOFTFP__"
    },
    {
      "rank": 9,
      "rule": "Vector lowering through SHAVEISD::{HORIZONTAL_*,CLAMP/MIN/MAX,SPLAT/LANESPLAT,UNPACK,LDISym,...}; BUILD_VECTOR uses constant pools unless shave-disable-constant-pools",
      "confidence": "[S] node names + option help"
    },
    {
      "rank": 10,
      "rule": "Alignment/sections: BB alignment must be 1 or 16 bytes else fatal; '.lalign' for aligned targets; 16-byte function targets; 8-byte stack; BRU.NOP (MI 0xaa9) compresses to no text but keeps the slot",
      "confidence": "[V] FUN_180097e00, FUN_180098ca0, option ctors; [S] moviAsm64 2476-2491/2747"
    }
  ],
  "peer_messages_sent": [
    "AsmEncodingRE x3 (assembler cross-check facts; -no6thSlotCompression correction + separator literal; rationale for declining the vanilla Ghidra diff + D7 ancestry result)"
  ]
}