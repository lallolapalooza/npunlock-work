{
  "status": "COMPLETE — closed, nothing left actionable",
  "gate": {
    "command": "cd /home/user/projects/npunlock-work/npunlock && ./tools/npu_add1_smoke.sh --elf /tmp/our2.elf  (NPUNLOCK_SMOKE_WORK_DIR=/tmp/smoke_postasm)",
    "exit_code": 0,
    "oracle": "all stages passed; oracle exact — ACTUAL == EXPECT 32/32 after the assembler update (shave-isa 13:55, D2d fadd-latency, shortfall-based: byte-identical ELF, no double-fill)'"
  },
  "independent_confirmations": [
    "MedicalCrayfish, from a clean `ninja -C build llc clang` after my changes: 3/3 runs rc=0, oracle exact, same ACTUAL bytes; structure gate PASSED (.text 496 B vs gold 192 B); offline ctest 15/15; gated byte-compare RED (1124 vs 828 B, accepted).",
    "AsmSchedImpl: no encoder rule added, G3 anchor `SAU.ADD.F32 i7,i7,i1 -> 3ce09c30` unchanged, my constant-selector table recorded in shave-isa/VALIDATION.md and relayed to AsmEncodingRE (who inverted the bytes independently and agreed)."
  ],
  "totals": "12/12 non-colliding oracle runs green (mine + MedicalCrayfish's), covering: toolchain-root ELF, .s with --no-legalize, and the post-assembler-update ELF.",
  "files_changed_by_me": [
    "llvm-14/llvm/lib/Target/SHAVE/SHAVEInstrInfo.td — FADD_F32_ONE (\"SAU.ADD.F32 $dst, $src1, i1\")",
    "llvm-14/llvm/lib/Target/SHAVE/SHAVEISelDAGToDAG.cpp — isF32OneConstant() + case ISD::FADD (no debug leftovers)",
    "llvm-14/llvm/lib/Target/SHAVE/SHAVEFillDelaySlots.cpp — fixFAddLatency + -shave-fadd-latency (default 3 slots)",
    "llvm-14/BYTE_EXACT_LOG.md — section 25 (measurement ledger, root causes, gate record, remaining gaps)"
  ],
  "artifact": "/home/user/projects/npunlock-work/our-add1-fp16.elf (1124 B, native toolchain root; the freshly re-baked post-assembler-update copy is /tmp/our2.elf, byte-identical to it)"
}