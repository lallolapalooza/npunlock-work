{
  "summary": "Right-sized the carrier tile (ladder per op) + claimed f32 SiLU; per-invocation cost 5.16-5.29 ms -> 2.48-2.60 ms (2.1x), model t/s 6.9/0.5 -> 9.8/1.3 (baseline 6.0/0.4), output byte-identical; selftest PASS 107/107.",
  "headline_numbers": {
    "per_invocation_ms": {
      "before": 5.157,
      "after": 2.484,
      "second_ab_pair_before": 5.291,
      "second_ab_pair_after": 2.599
    },
    "model_cli_tps_prompt_generation": {
      "before": "6.9 / 0.5",
      "after": "9.8 / 1.3",
      "second_pair": "6.3 / 0.5 -> 8.2 / 1.2",
      "parent_baseline": "6.0 / 0.4",
      "cpu_only": "12.9 / 6.2"
    },
    "npu_ms_same_run": {
      "before": 4780.38,
      "after": 2302.71
    },
    "invocations": 927,
    "offloaded": 927,
    "declined": 65357,
    "elements_offloaded": 5765632,
    "tile_histogram": {
      "before": {
        "131072": 927
      },
      "after": {
        "16384": 505,
        "32768": 168,
        "65536": 127,
        "131072": 127
      }
    },
    "selftest": "PASS, 107 checks ok, 0 FAIL, 23 offloads, 171.052 ms NPU time",
    "engine_id": "f3b0bb813f176979597d8516713fea51be9493d8c243344eb3515ee95e7bb542",
    "libggml_shave_sha256": "7c478b7fa1d8811c1d41b9d0d108a9e50b63a89c184bf8cb3b6718ec37aee708"
  },
  "change": {
    "root_cause": "A patched carrier executes its WHOLE tensor per invocation, so per-invocation device time is set by the carrier's slot count, not by the payload. The engine carried only the 131072-byte (65536-slot) rung, so the model's dominant 2560-f32 (10240-byte) tensor paid 12.8x wasted work. Measured serialized medians in one process (Maximum carriers patched with shave_add_f32): 16384 B 1.635 ms, 32768 B 2.059 ms, 65536 B 2.957 ms, 131072 B 4.896 ms.",
    "fix": "Carrier ladder 16384/32768/65536/131072 B for every engine op (new IRs + vendor-compiled blobs), ggml_shave_engine_tile_for(op,payload) picks the smallest rung >= payload; graph_compute stages into that rung; stats report a tile_histogram.",
    "op_set": "ADD, MUL, CONT (bit-exact) + SILU (declared <=4 ULP, measured worst 3 ULP); earlier revision claimed only add/mul/copy.",
    "files": [
      "ggml/src/ggml-shave/tools/build_kernels.py (ladder + kernel-lib ELF support + engine_id)",
      "ggml/src/ggml-shave/tools/ir/{maximum,abs}{8192,16384,32768}*.xml (6 new carrier IRs)",
      "ggml/src/ggml-shave/kernels/carriers/*.blob (6 new, 2 regenerated bit-identically)",
      "ggml/src/ggml-shave/shave-engine.{h,cpp} (per-(op,rung) kernels, rung selection, engine_id)",
      "ggml/src/ggml-shave/ggml-shave.cpp (silu gate, rung staging, tile_histogram, engine_id, census sub-op names, atexit fix)",
      "ggml/src/ggml-shave/tests/shave-selftest.cpp (ladder cases + silu ULP test)",
      "ggml/src/ggml-shave/CMakeLists.txt (GGML_SHAVE_KERNEL_LIB, carrier glob deps)",
      "ggml/src/ggml-shave/README.md, ggml/include/ggml-shave.h"
    ],
    "bug_found_and_fixed": "Processes that had offloaded never exited: census_dump()/shave_stats_dump() run from atexit and iterate function-local std::map statics whose own __cxa_atexit destructor runs first, so the iteration walked a freed tree and spun in std::_Rb_tree_increment (gdb: llama-bench thread 1 inside shave_stats_dump). Hit llama-cli/llama-bench with GGML_SHAVE_STATS=1 (and the pre-existing census map with GGML_SHAVE_CENSUS=1). Both maps are now deliberately leaked heap singletons; llama-cli/llama-bench exit 0 and print the stats line."
  },
  "commands": {
    "build": "cmake -B build -DGGML_SHAVE=ON && ninja -C build llama-cli llama-bench ggml-shave-selftest",
    "selftest": "TMPDIR=/var/tmp/npu-scratch/GGMLBackend-4 LD_LIBRARY_PATH=.../npunlock/build/fresh ./build/bin/ggml-shave-selftest",
    "ab": "build/bin/llama-cli -m ../models/gemma-4-E4B-it-Q4_0.gguf -dev SHAVE0 -p 'What is the capital of France? Answer with only the city name.' -n 16 -c 4096 -t 8 --temp 0 -s 1234 -co off -st --no-warmup -fit off -b 2048 -ub 512   [before = same binary/command with an otherwise identical lib built from LADDER_BYTES=(131072,)]",
    "census": "GGML_SHAVE_CENSUS=1 GGML_SHAVE_STATS=1 <same command>"
  },
  "op_table": [
    {
      "op": "GGML_OP_ADD (f32)",
      "kernel": "kernels/shave_add_f32.c, Maximum two-input carriers",
      "verified": "bit-exact vs CPU backend on all 4 rungs + sub-tiles + 1 element + mixed scheduler graph (selftest, 12 bit-exact NPU checks)"
    },
    {
      "op": "GGML_OP_MUL (f32)",
      "kernel": "kernels/shave_mul_f32.c, Maximum carriers",
      "verified": "bit-exact, same cases"
    },
    {
      "op": "GGML_OP_CONT (dense byte copy)",
      "kernel": "kernels/shave_copy.c, Abs carriers",
      "verified": "byte-exact on f32 and f16 raw random bytes over the full ladder"
    },
    {
      "op": "GGML_UNARY_OP_SILU (f32)",
      "kernel": "kernel-lib elf/silu_f32.elf on Abs carriers",
      "verified": "within declared 4 ULP of the CPU backend at 1024/8192/32768 elements (worst 3 ULP; 265/2112/8383 elements differ, i.e. tolerance genuinely exercised)"
    }
  ],
  "measured_declines": [
    {
      "op": "gelu_f32 (kernel-lib ELF and a fresh recompile with the live toolchain)",
      "measurement": "max relative error 1.4e7, 8153/8192 elements wrong vs a host tanh-GELU reference; no NaN, full coverage",
      "verdict": "declined - kernel is numerically wrong; consistent with the open integer-multiply defect in FINDINGS.md"
    },
    {
      "op": "scale_f32 (kernel-lib ELF and a fresh recompile)",
      "measurement": "max relative error 0.455 == exactly |0.75-1.375|/1.375, i.e. it multiplies by the per-element second record instead of element 0",
      "verdict": "declined - kernel-lib's multi-input record indexing does not match the 0x28-stride record array our carriers expose"
    },
    {
      "op": "RMS_NORM / SOFT_MAX / ROPE / MUL_MAT",
      "measurement": "ggml semantics (weight tensor, mask+scale, positions, contraction) are not modelled by kernel-lib's reduce_rows/rope/vec_dot kernels; MUL_MAT also exceeds one tile",
      "verdict": "declined"
    },
    {
      "op": "f16 elementwise (ADD/MUL/SILU)",
      "measurement": "fp16-typed store drops lanes on the current toolchain (2012/65536 measured)",
      "verdict": "declined"
    }
  ],
  "coverage_census": {
    "signatures": 282,
    "offers_accepted": 1586,
    "offers_declined": 66918,
    "declined_by_op": {
      "MUL": 17618,
      "RMS_NORM": 14886,
      "MUL_MAT": 11184,
      "NONE(leaves)": 8832,
      "SET_ROWS": 2304,
      "VIEW": 2016,
      "PERMUTE": 2016,
      "ADD": 1907,
      "CONT": 1872,
      "ROPE": 1605,
      "UNARY(GELU)": 1032,
      "GLU(GEGLU)": 1008,
      "TRANSPOSE": 924,
      "SOFT_MAX": 924,
      "SCALE": 156,
      "GET_ROWS": 136,
      "FLASH_ATTN_EXT": 84
    },
    "key_finding": "The model's activation is GELU/GEGLU, NOT SILU - the only activation kernel I could verify is not on gemma-4-E4B's path (per_op_invocations silu:0). MUL declines are mostly a broadcast operand or >1 tile; the accepted subset is small dense f32 ADD/MUL."
  },
  "op_economics": {
    "cpu_npu_comparison": "CPU backend graph_compute (-t 8, 1500 reps): 2560 f32 ADD ~32 us, MUL ~25 us, CONT ~46 us, SILU ~46 us; 32768 f32 ADD ~40 us, SILU ~65 us. A 1-element graph already costs 15-29 us, so small-tensor CPU figures are dominated by the backend's own dispatch. NPU: 1.6 ms (16384 B rung) / 4.9 ms (131072 B rung).",
    "verdict": "elementwise loses by 35-120x; even an expf-class activation would need ~100x more arithmetic per element to break even against the ~1 ms fence wait + ~0.06 us/fp16 slot. The only lever with the measured numbers to change this is batching independent nodes (0.38-0.48 ms marginal per execution, npu-runtime), not tile choice.",
    "mul_mat_eligibility": "Out of reach: the ACT tile must hold the whole op and a MUL_MAT weight is ne0 x ne1 of the output; the smallest MUL_MAT signature the model offers is q4_0 ne=[2560,1,1,1] => a 2560x2560 Q4_0 weight = 3.3 MB, 25x the largest rung (largest 22 MB). The ACT ABI has no accumulator/cross-invocation state and npunlock does not split tiles. Only dense f32 matmuls with both operands+output under ~32k elements could fit one rung (e.g. ne=[64,64]); none occur in this model."
  },
  "blockers": [
    {
      "what": "kernel-lib's gelu_f32 and scale_f32 produce wrong values on the NPU (reproduced with both the shipped ELF and a fresh compile with the live toolchain); scale's error identifies it as a multi-input record-indexing mismatch, gelu's as a miscompile",
      "error": "no error - silent wrong results (max rel 1.4e7 and 0.455)",
      "impact": "GELU (the model's actual activation) and SCALE stay on the CPU"
    },
    {
      "what": "no batching",
      "error": "n/a - correctness constraint: nodes inside one ggml_backend_sched split are dependent, so a batch may only contain nodes none of whose sources is another node of the batch; only npurt_kernel_clone+npurt_run_batch_inputs are available and unused",
      "impact": "~1 ms fence wait is paid per node; the ~0.4-0.5 ms batched marginal is not realised"
    },
    {
      "what": "npunlock rejects f32-typed ACT carriers",
      "error": "patchblob.validate_contract: output tensor does not match the expected element contract",
      "impact": "fp32 kernels must run on f16 carriers through byte windows"
    },
    {
      "what": "eval/tools/npu_engine_cost.py drives build/bin/ggml-shave-runner --serve and parses one embedded blob out of shave-kernels.inc",
      "error": "the runner's source and CMake target no longer exist (only a stale binary from 15:21 did; I deleted it), and the .inc now embeds 16 blobs",
      "impact": "that harness tool needs updating by its owner; the prompt-set harness itself (run_compare.sh) is unaffected by my change except the new stats fields"
    }
  ],
  "verification_evidence": {
    "selftest": "/home/user/projects/npunlock-work/ggmlback-4/selftest-final.out (107 ok / 0 FAIL / PASS)",
    "model_ab": "/home/user/projects/npunlock-work/ggmlback-4/model-{before-compare,after-ladder}.{out,err} (identical text, stats lines)",
    "census": "/home/user/projects/npunlock-work/ggmlback-4/census-282-signatures.txt",
    "bench": "/home/user/projects/npunlock-work/ggmlback-4/bench-{before,after}.out",
    "notes": "GGML_SHAVE=OFF is untouched (the backend is not built). The stats line keeps every field it had (ops/invocations/offloaded/declined/unsupported/elements_offloaded/tile_bytes/lanes/per_op_invocations/setup_ms/npu_ms/avg_invocation_us) and adds silu to lanes plus tile_histogram and engine_id."
  }
}