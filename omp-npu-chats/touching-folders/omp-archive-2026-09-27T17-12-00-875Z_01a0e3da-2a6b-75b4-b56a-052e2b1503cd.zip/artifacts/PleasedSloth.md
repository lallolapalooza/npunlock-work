{
  "status": "INCOMPLETE — acceptance gate NOT met",
  "headline": "npu_add1_smoke.sh --elf <ours> still exits 1 (oracle failed). I did NOT achieve the gate. One real root-cause-class encoder bug was found and fixed; a measurement-channel defect that invalidated most prior FAULT-based conclusions was diagnosed and fixed; the remaining blocker is precisely characterized.",
  "gate_evidence": {
    "command": "cd /home/user/projects/npunlock-work/npunlock && ./tools/npu_add1_smoke.sh --elf /tmp/iterF/ours.elf",
    "result": "rc=1; stages loader..execution all passed; oracle FAILED",
    "actual": "00010000ffffff000000803f000000bf20010000ffffff000000803f00e0ddbe (= carrier-init baseline, zero writes land)",
    "expect": "00c3bcbde0b56832223a553c9a3dde3f11421a442b459e48534c2c5017540c58",
    "control": "same script with tmpdump/full.elf (gold .text bytes verbatim) => rc=0, oracle exact — transport/harness is sound"
  },
  "what_I_delivered": [
    "ROOT-CAUSE CLASS FIX (landed in shave-isa/encodings.json by peer AsmEncodingRE, independently verified by me): ST/STI.16.F32.F16 operand field map was wrong. Vendor map = value at LE bits[16:12]|bit8<<4, base at LE bits[21:17], unit word 0x42040000/0x49240000, STI sets LE bit 27. Verified byte-exact vs all 6 vendor anchors: (i6,i5)->42640a00, (i7,i8)->42741000, (i8,i7)->42840e00, (i10,i29)->42a43a00, STI (i6,i5)->49640a08, STI (i7,i8)->49741008. Before the fix our real kernel emitted 42c41400 for (i6,i5) = 'i12,i10' — a store through a garbage base register.",
    "Real kernel store now emits 42340000 = ST.16.F32.F16 i3, i0 (verified by disassembly); the garbage-register store is gone.",
    "MEASUREMENT-CHANNEL AUDIT: rapid-fire NPU probe runs on this box produce SPURIOUS 0x70000001 faults. Proven with byte-identical ELF+bundle pairs (r0/B1): pass 3/3 alone, fault 5/5 inside a Python subprocess batch loop. Shell-loop invocation is deterministic. Also found and fixed my own harness bug (appended duplicate BRU.JMP i30 epilogue -> different kernel than the pipeline).",
    "Reliable-channel re-confirmation of two hard constraints, measured on gold bytes through the real smoke: (a) substituting the 0x8d out-ptr read with the c2/fmt0 class => FAULT, so the 01 class (fmt110 = 0182645100) is semantically REQUIRED for the out-pointer; (b) plain ST (42741000) instead of indexed STI => wrong values (no implicit increment).",
    "The 01 class IS usable in our own context: LSU0.LDO.32 i0,i18,0x28 ; fmt=110 executes PASS (no fault) in the real kernel — the prior 'fmt110 faults in our context' conclusion was a measurement artifact.",
    "Reachability bisection with size-preserving wild-store witnesses (LSU0.ST.16 i5,i5) in the real kernel: guard3 (dims==0), guard4 (dim>16/count), fp-loop backedge and the store site are ALL reached => the kernel does NOT early-exit; guards/loops execute. The failure is purely that the store target is not the oracle window.",
    "BYTE_EXACT_LOG.md: appended 'Iteration 19' with the full encoder fix table, the read-class/STI constraints, the measurement-channel audit and the reachability table.",
    "Gated ctest recorded (expected RED, not faked): NPUNLOCK_SHAVE_TOOLCHAIN_DIR=... ctest --test-dir build/e2e -R shave_add1 --output-on-failure => 1/1 FAILED: 'linked ELF differs from the retained repeatable build (900 versus 828 bytes)'."
  ],
  "remaining_blocker": "Kernel executes fully (guards + count loop + fp loop + store site all reachable) but no write lands in the 32-byte oracle window; ACTUAL is exactly the carrier-init baseline. All tested combinations of out-ptr read class (fmt0/110/113/112/1) x store form (ST/STI) x all-LDO-class variants (all-c2 / all-01 / all-f9) still do not land, while gold's own bytes land byte-exactly. Since a c2-class substitution at 0x8d breaks GOLD itself, and the 01 class is proven usable in our context, the remaining variable is the in-pointer/out-pointer provenance chain (the still-undecoded gold runs) — next step per plan is the C3'' composite boundary scan (gold 0x00-0x8c + our read + gold 0x8e-end).",
  "no_hand_patched_bytes": "All verified results above were produced from real .s sources compiled by our backend / assembled by shave_asm.py; .byte composites were used only as diagnostic controls on gold's own bytes, never to claim a pass.",
  "text_ratio": "272 B ours vs 192 B gold = 1.42x (structure gate iter_compare.sh green)",
  "artifacts": [
    "/home/user/projects/llvm-14/BYTE_EXACT_LOG.md (Iteration 19)",
    "/tmp/diag/ smoke.sh, mkv3.sh, byt.sh (reliable probe channels)",
    "/home/user/projects/llvm-14/tmpdump/full.elf (gold transport control, rc=0)",
    "/home/user/projects/llvm-14/llvm/lib/Target/SHAVE/SHAVEInstrInfo.td (ST16F32 comment updated; reverted to plain ST pending the in-ptr class fix)"
  ]
}