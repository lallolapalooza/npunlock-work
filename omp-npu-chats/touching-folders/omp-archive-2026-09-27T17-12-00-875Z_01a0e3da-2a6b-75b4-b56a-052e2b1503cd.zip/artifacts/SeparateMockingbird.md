{
  "status": "complete_deliverables_written",
  "note": "Main ordered shutdown; both deliverable files confirmed on disk (741 lines total). No wine used for the final evidence set except the retired probe facts already captured.",
  "deliverables": [
    {
      "path": "/home/user/projects/npunlock-work/rptrace/TRACE_REPORT.md",
      "lines": 409,
      "content": "Q1-Q6 answers, each with file:line RE evidence, FIX FOR BACKEND line, confidence label, plus ordered backend action table"
    },
    {
      "path": "/home/user/projects/npunlock-work/rptrace/SUPPORTING.md",
      "lines": 332,
      "content": "verbatim vendor template/mnemonic/diagnostic lines with line numbers, encoder record tables, gold bytes"
    }
  ],
  "Q1_store_semantics": {
    "answer": "Vendor emits LSU1.STI.16.F32.F16 <f32value:iN>, <base:iN> -- value FIRST, base SECOND, both SCALAR I-class. Auto-increment is IMPLICIT +2 bytes (element size); there is NO increment operand. ST vs STI differ only in bit 3 of the last byte (0x00 vs 0x08) and are distinct MI opcodes/tables.",
    "evidence": [
      "moviAsm64/decompiled_all.c:370979 FUN_180433f50(...,\"LSU0.STI.16.F32.F16\",...) with records {D,0x40,9}{IR,1,5}{IR,0,5}{D,0x442,13}",
      "moviAsm64/decompiled_all.c:392647 LSU1.ST.16.F32.F16 records {D,0x449,13}{IR,0,5}{IR,1,5}{D,0,9}",
      "movicomp/decompiled_all.c:240356 printer \".STI.16.f32.f16 \" (case 0xa0) vs :240993 \".ST.16.f32.f16 \" (case 0xd5)",
      "moviAsm64 strings :4421 LSU0.STI.16.F32.F16; moviCompile strings :87908 .STI.16.f32.f16"
    ],
    "why_ours_wrong": "42c41400 decodes under the vendor field map (val=bits[23:20]+bit8, base=bits[13:9]) to LSU0.ST.16.F32.F16 i12,i10 -- NOT (i6,i5). Correct encoding for (i6,i5) is 42640a00 (ST) / 42640a08 (STI).",
    "fix": "Emit LSU1.STI.16.F32.F16 iVal,iBase with val=bits[23:20]|(bit8<<4), base=bits[13:9], base word 0x42040000(LSU0)/0x49240000(LSU1), |0x08 for STI; move out-ptr advance to the STI implicit increment; keep in-ptr advance as explicit IAU.ADD in,in,2.",
    "confidence": "HIGH"
  },
  "Q2_register_files": {
    "answer": "SHAVE DOES have separate VRF/WVRF (vector) and IRF (integer) file views -- Generic::ScalarRC / Generic::VectorRC, IRF8_q0..q3, IRF16_h/l, VRF16_e0..e7, WVRF32/128/256/512, and cross-file node LSU_CP16_vrf_irf0. BUT this kernel's SAU.ADD.F32 / LD.32.F16.F32 / STI.16.F32.F16 all take scalar iN operands in the IRF: our i-register choice is CORRECT and is NOT the zero-write bug. Plain ST.16 (no convert) is the odd one: its value operand must be V-class (vN.S), base I-class.",
    "evidence": [
      "moviCompile64 strings :78365-78366 Generic::ScalarRC/VectorRC",
      "moviCompile64 strings :79259-79291 IRF*/VRF*/WVRF* views, :79309 LSU_CP16_vrf_irf0",
      "class tokens VR/VW/IW/IR/I/V at .rdata VA 0x180692ea8 (shave-isa/ENCODING_NOTES.md sec.1)"
    ],
    "fix": "Keep iN for all three scalar fp ops. Never emit a V-class value for STI.16.F32.F16/SAU.ADD.F32. If plain ST.16 is ever emitted, value MUST be V-class or the encoder is wrong.",
    "confidence": "MEDIUM-HIGH (Myriad2Platform builder FUN_180434100 is DECOMPILE_FAILED at moviAsm64/decompiled_all.c:170229, so any Myriad2-only aliasing rule is not extractable)"
  },
  "Q3_guard_codegen": {
    "answer": "Vendor guard = LSU0.LDO.32 rank<-i18,0xc ; LSU0.LDO.32 dims<-i18,0x10 (DEREF of the pointer value) then CMU.CMZ.I32/CMU.CMII.U32 flag + DIRECT predicated BRU.BRA to epilogue (no XOR inversion). rank>15 compares against materialised 15 (LDIL i8,0xf). 16/count is a REAL SAU.DIV.U32 (gold 0x5d), not strength-reduced. dims is deref'd via the +0x10 load then indexed by d*4; the 0x50 RELA addend applies to the params section, not to dims.",
    "evidence": [
      "gold .text 0x0000/0x0005/0x0018/0x0050-0x0073 (add1-fp16.elf bytes)",
      "moviCompile64 strings :78440 shave-predicator; :78472-78479 SHAVEISD::RET_FLAG/SETCC/SELECT",
      "npunlock source add1-fp16.c guard"
    ],
    "fix": "Guard on !dims via CMU.CMZ.I32; prefer CMU.CMII.U32 imm-compare for rank>15; drop the extra IAU.XOR predicate inversion (branch sense carries the negation); keep deref semantics for dims.",
    "confidence": "MEDIUM"
  },
  "other_answers": {
    "Q4": "Loop = LD.32.F16.F32 -> SAU.ADD.F32 -> STI.16.F32.F16 (implicit out+=2) -> explicit IAU.ADD in,in,2 -> IAU.INCS counter -> CMU.CMZ.I32 flag -> predicated BRU.BRA back to 0x98; epilogue BRU.JMP i30. Backedge condition source = the flag register set by CMU.CMZ.I32.",
    "Q5": "LDO byte-0 class (0xc2 LSU0 / 0xc9 LSU1) selects LSU unit + opcode(LDO/LD/ST) + width in the 13-bit D record -- NOT an address space. Immediate is scale-4. Gold's 01-class at 0x8d is [INFERENCE] the LSU1/alternate-slot or X-slot overlay, not a different addressing capability; prefer the vendor-emitted c982645100 LSU1 form.",
    "Q6": "[INFERENCE LOW-MEDIUM] Plain ST.16 does not hit a different address space; it is a vector-class element store (needs vN.S value) and is a distinct MI opcode; the zero-write is explained by the wrong store encoding (42c41400 -> i12,i10) plus slot/bundle-level illegality (0x70000001), whose opcode-byte difference 0x89 vs 0xa9 is slot-position dependent."
  },
  "retired_method_facts_recorded_in_report": [
    "LSU1.STI.16.F32.F16 i7,i8 -> 49741008 (exact gold match)",
    "LSU0.STI.16.F32.F16 i7,i8 -> 42741008; LSU0.ST.16.F32.F16 i6,i5 -> 42640a00",
    "LSU1.LDIH i4,0x3F80 -> 8923803f standalone vs a923803f inside a 2-slot pipe => 0x89/0xa9 is the slot-position bit",
    "explicit bundle syntax A || B || C confirmed by moviCompile64 strings :78385 BRU.SWIH 1 || LSU0.LDIL i18,0xFFFF || LSU1.LDIH i18,0xFFFF",
    "register grammar: integer iN (expected format I<regNo>) vs vector vN.S (V<regNo>.<subregNo>)",
    "BRU.NOP is the fill; BRU.INC -> 07; BRU.JMP i30 -> 47f100",
    "our tables differ from vendor in specific forms (ST.16.F32.F16 operand field map; LSU0.STI.16.F32.F16 opcode constant)."
  ]
}