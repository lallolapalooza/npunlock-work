{
  "summary": "POSIX port of npunlock's IR graph-compile worker is complete and verified: Linux now compiles NEW NPU carriers from OpenVINO IR through the shipped path (no wine/Windows binaries/network), patches compiled SHAVE kernels into them, and executes them on the Meteor Lake NPU with exact host-reference oracles at 512/2048/8192 f16 elements per ACT invocation (1x1024, 1x4096, 1x16384 carriers). ctest 16/16 (was 15/15), add1 gate exit 0 + oracle exact 32/32.",
  "diagnosis_confirmed_with_correction": {
    "confirmed": [
      "src/workers/ir_worker.c:1-2 was win32-only (#define WIN32_LEAN_AND_MEAN / #include <windows.h>) with exactly these Windows APIs: HMODULE/FARPROC, LoadLibraryExW(L\"ze_loader.dll\",NULL,LOAD_LIBRARY_SEARCH_SYSTEM32), GetProcAddress, FreeLibrary, GetStdHandle(STD_INPUT_HANDLE), ReadFile/WriteFile via worker_io.h, SetErrorMode, CloseHandle; response handle parsed from '--response-handle N'.",
      "CMakeLists.txt built npunlock_worker only under if(WIN32), so on Linux nothing supplied the worker binary the transport spawns (posix_spawn ENOENT -> NOT_FOUND -> 'Level Zero worker failed ...').",
      "The POSIX transport (src/common/worker_process_posix.c -> libnpunlock_posix_worker_process.a) and the wire protocol (48-byte request / 88-byte response, magics 0x4957504e/0x4f57504e) already existed and are tested.",
      "ZE graph extension is reachable on Linux: this machine has intel-level-zero-npu 1.38.0 + intel-driver-compiler-npu 1.38.0, and NGRAPH_LITE compilation works (compiler 8.3, device_id 32029)."
    ],
    "correction": "src/ir2blob/ir_worker_win32.c contained NO Windows API: it is transport-neutral request framing over npunlock_worker_process_run and was already compiled into libnpunlock.so on Linux (nm -D showed T npunlock_run_ir_worker). The genuine Linux gaps were the missing POSIX worker executable and the win32-only worker source, not the launcher. The file is renamed ir_worker_process.c to reflect that and is used by both platforms.",
    "not_windows_specific": [
      "src/workers/worker.c (0 Windows API hits)",
      "src/workers/level_zero_min.h (0 hits)",
      "src/workers/ir_protocol.h, worker_protocol.h (portable)"
    ]
  },
  "port": {
    "approach": "Shared portable core + thin platform layer; Windows behaviour byte-identical.",
    "files_added": [
      "src/workers/worker_platform.h (library open/symbol/close, response sink, request read, response write, process prep, ZE loader name)",
      "src/workers/worker_platform_posix.c (dlopen(\"libze_loader.so.1\", RTLD_NOW|RTLD_LOCAL)+dlsym, sink = fd from '--response-fd N' (fd 3 as the transport passes), read()/write() loops, SIGPIPE ignored)",
      "src/workers/worker_platform_win32.c (LoadLibraryExW with LOAD_LIBRARY_SEARCH_SYSTEM32, GetProcAddress, '--response-handle' via existing worker_io.c, GetStdHandle/ReadFile/WriteFile, SetErrorMode)"
    ],
    "files_changed": [
      "src/workers/ir_worker.c: now platform-free shared core (no windows.h); own ir_checked_add; loader diagnostic names the platform library",
      "src/workers/worker.c: 'movi' dispatch wrapped in #if defined(_WIN32); 'ir' mode works on both platforms",
      "src/ir2blob/ir_worker_win32.c -> src/ir2blob/ir_worker_process.c (git mv, no logic change)",
      "CMakeLists.txt: npunlock_worker built on POSIX (worker.c + ir_worker.c + worker_platform_posix.c, links CMAKE_DL_LIBS) and installed as Runtime; ir2blob objects use ir_worker_process.c; FORMAT_SOURCES updated",
      "src/linux_probe/main.c: removed the hardcoded 32-byte tensor requirement (now equal, nonzero, even-sized) and added INPUT/EXPECT/ACTUAL evidence + first/last mismatch index on oracle failure",
      "tools/porting_probe.py: additive '--element-count N' and '--oracle fp16_add1_exact' (generic binary16(x)+1, no carrier ramp); defaults byte-identical for the existing gate",
      "tests/integration/test_ir2blob.c: ported to POSIX (fopen/ftell instead of fopen_s/_fseeki64), unblocking the gated npu_ir2blob_abs test on Linux",
      "docs: README.md, wiki/PORTING.md (Milestone 5 implemented), wiki/DEVELOPMENT.md, wiki/CUSTOM_KERNELS.md (IR carrier layout + kernel-shape traps), wiki/LIMITATIONS.md, wiki/PORTING_PROBE_BUNDLE.md, docs/C_API.md, tests/fixtures/README.md"
    ],
    "new_fixtures": [
      "tests/fixtures/npu3720/add1-wide.c (add-one ACT entry without the 16-element clamp of add1-fp16.c; single store in a raw loop)",
      "tests/fixtures/npu3720/maximum-2input-1x1024.xml (2-input Maximum IR for 2-input carriers)"
    ],
    "new_tests": [
      "ctest porting_ir_worker_posix (tests/unit/test_ir_worker_posix.c): drives the real built npunlock_worker through the shipped transport; malformed request must yield a well-framed BAD_REQUEST, valid Abs(1,16) request must yield an ELF blob or a categorized non-empty diagnostic",
      "gated ctest npu_ir2blob_abs (now compiles+passes on Linux)",
      "gated ctest npu_carrier_smoke (runs tools/npu_carrier_smoke.sh end-to-end; registered only when NPUNLOCK_SHAVE_TOOLCHAIN_DIR is set)"
    ]
  },
  "commands": {
    "one_command": "cd /home/user/projects/npunlock-work/npunlock && ./tools/npu_carrier_smoke.sh --elements 1024 --toolchain-dir /home/user/projects/npunlock-work/shave-toolchain-root   # also 4096, 16384",
    "shipped_cli": "./build/fresh/npurun build --ir abs-1x1024.xml --shave-source tests/fixtures/npu3720/add1-wide.c --toolchain-dir /abs/shave-toolchain-root --patch-position 0 --ir-worker ./build/fresh/npunlock_worker --output carrier-1x1024.blob --manifest build.json   # --ir-worker optional: default resolves npunlock_worker next to the caller",
    "inspect_bundle_probe": "./build/fresh/npunlock-inspect --graph carrier-1x1024.blob | python3 tools/porting_probe.py create --graph carrier-1x1024.blob --output-dir bundle --producer-platform linux --device npu --driver-version 1.38.0 --graph-compiler-version 8.3 --element-count 1024 --oracle fp16_add1_exact && python3 tools/porting_probe.py verify bundle && ./build/fresh/npunlock-linux-probe --bundle bundle --report report.json",
    "library_api": "NativeLibraries(\"build/fresh\").compile_ir(xml_bytes, b\"\", worker=\"build/fresh/npunlock_worker\")  # bare carrier; worker= optional",
    "ir_helper": "tools/npu_carrier_smoke.sh writes the Abs(1,N) IR it uses to <work>/abs-1xN.xml"
  },
  "carrier_contracts": {
    "1x1024": {
      "blob_bytes": 42480,
      "act_groups": 1,
      "act_targets": 4,
      "f16_elements_per_invocation": 512,
      "span_bytes": 1024,
      "dtype": "fp16",
      "contract_flags": 31
    },
    "1x4096": {
      "blob_bytes": 42480,
      "act_groups": 1,
      "act_targets": 4,
      "f16_elements_per_invocation": 2048,
      "span_bytes": 4096,
      "dtype": "fp16",
      "contract_flags": 31
    },
    "1x16384": {
      "blob_bytes": 42480,
      "act_groups": 1,
      "act_targets": 4,
      "f16_elements_per_invocation": 8192,
      "span_bytes": 16384,
      "dtype": "fp16",
      "contract_flags": 31
    },
    "2input_maximum_1x1024": {
      "blob_bytes": 63424,
      "act_groups": 1,
      "act_targets": 4,
      "f16_elements_per_invocation": 256,
      "input_count": 2,
      "note": "records 0/1 = inputs, record 2 = output; N=16384 -> 4096 per invocation"
    },
    "measured_layout_abs_family": {
      "rule": "E = N/2; the two load-bearing invocations (of 4) get BOTH their input and output record pointers windowed contiguously at tensor element offset k*E, cover [0,E) and [E,N), and see count = product(dims) = E",
      "how_verified": "out[i] = in[0] + 1.0f produced exactly two constant runs [0,512) = -511.0 and [512,1024) = 1.0 with input x[i]=i-512, i.e. the two in[0] values were x[0] and x[512]; cross-checked with bit-exact two-load kernels.",
      "in_count_read": "NOT established: the kernel that tried to sample in[count]/in[count+1] never landed a store (see limitations)."
    }
  },
  "measured_host_vs_npu": [
    "1x1024 add1-wide.c: npunlock-linux-probe all 7 stages passed, oracle fp16_add1_exact exact (1024/1024 elements; 2048/2048 bytes).",
    "Independent check: the probe's printed ACTUAL (2048 B) decoded in python equals the host reference f16(f16(x)+1) byte-for-byte (0/2048 differing). Negative control: corrupting one expected byte is detected ('1/2048 bytes differ; first at 0 (expected 0x01, actual 0x00)').",
    "1x4096: 2048 f16 per invocation, 3/3 runs exit 0 + oracle exact. 1x16384: 8192 f16 per invocation, 3/3 runs exit 0 + oracle exact.",
    "Independent binary/register-form kernels on 1x1024, each 1024/1024 bit-exact vs a windowed host reference (max abs diff 0.0): out[i]=(__fp16)((float)in[i]+(float)in[i^256u]); out[i]=in[i]+in[i+256u]; out[i]=in[i&255u]+in[(i&255u)+256u]; out[i]=in[i]+in[0].",
    "Third-party reproduction: MultiOpProbe ran tools/npu_carrier_smoke.sh --elements 4096 and matched its independent ircompile carrier contract (4 targets / 2048 f16 per invocation / span 4096 B) and warm-execute times (0.232 ms vs 0.241 ms). GGMLBackend-2/3 also reproduced the carrier and wide-kernel path."
  ],
  "evidence_paths": {
    "carriers_and_reports": "build/fresh/npu-carrier/{carrier-1x1024.blob,carrier-1x1024.inspect.json,carrier-1x4096.blob,carrier-1x16384.blob,bundle-1xN/,execution-report-1xN.json}",
    "layout_probes": "build/fresh/npu-carrier/tileprobe/{tile_probe.c,patched2.blob,bundle2/,stderr2.txt}; tileprobe2/{reveal_tile.c,binary_add.c,*.blob,stderr-*.txt}; tileprobe3/{fold_a,fold_e,fold_x,fold_cast}.{c,blob}, carrier-1x1024.bare.blob, fold_cast.elf (1204 B, sha256 b316da1f95124be80071315fa1ff32022f9744c3ffbc37f1254f9a7562550356), repro.blob, bundle-repro/, stderr-repro.txt",
    "two_input_carriers": "build/fresh/npu-carrier/two-input/{maximum-1x1024.blob,maximum-1x16384.blob,*.inspect.json}",
    "logs": "/tmp/gate-final.log, /tmp/final-1024.log, /tmp/final-4096.log, /tmp/carrier-*-*.log"
  },
  "status": {
    "ctest_default": "16/16 passed (was 15/15; +porting_ir_worker_posix)",
    "add1_gate": "./tools/npu_add1_smoke.sh --elf ../our-add1-fp16.elf -> exit 0, all stages passed, oracle exact (driver_index=0, device_id=32029)",
    "gated_npu_tests": "with -DNPUNLOCK_ENABLE_NPU_TESTS=ON -DNPUNLOCK_ENABLE_SHAVE_TOOLCHAIN_TESTS=ON: npu_ir2blob_abs Passed, npu_carrier_smoke Passed",
    "toolchain_gate": "shave_add1 gated byte-compare remains RED as before (accepted class) - untouched by this work.",
    "no_wine_network": true
  },
  "remaining_limitations": [
    {
      "issue": "Multi-store kernels still silently no-op on wide IR carriers even after CorpusWave2's $r18 LowerFormalArguments fix",
      "exact_observation": "The 5-store marker kernel (u16 stores out[0]=count, out[1]=rank, out[2]=in[0], out[3]=in[count-1], out[4]=in[count]) reports stages execution=passed with status ok and empty diagnostic, but the output buffer stays at the uniform 0x0002 pattern (f16 1.1920928955078125e-07) - i.e. nothing landed. Single-store loop kernels are the reliable shape.",
      "artifacts": "build/fresh/npu-carrier/tileprobe/{tile_probe.c,patched2.blob,bundle2/,stderr2.txt}"
    },
    {
      "issue": "Hoisting a __fp16 scalar above the loop fails to compile",
      "exact_error": "error: SHAVE: unsupported IR node in wave 1: t61: i32 = FrameIndex<0> / fatal error: error in backend: SHAVE backend wave 1: unsupported IR (CorpusWave2 confirms the frame/spill support is a known unlanded gap)"
    },
    {
      "issue": "Reads past the chunk (in[count], in[count+1]) are unmeasured",
      "why": "the only kernel that tried to sample them never landed any store, so no evidence exists; kernels must not rely on it"
    },
    {
      "issue": "Chunk width and patchability are the driver compiler's choice, not settable",
      "evidence": "Abs/Maximum(1,N) -> 4 targets with E=N/2; multiop measured Add/Multiply/Relu/Clamp/Subtract as DPU-only (no ACT sections) and Ceil/Negate IR compile failures. Only 2 of the 4 Abs targets are load-bearing."
    },
    {
      "issue": "Windows build of the ported worker is not compile-verified here",
      "why": "no MSVC/Windows host available; the win32 platform file only re-uses the pre-existing worker_io.c calls and the pre-existing '--response-handle' argv contract, and ir_worker.c's Windows logic is unchanged apart from the loader-open/close and response-write calls",
      "risk": "low but untested"
    },
    {
      "issue": "Transient toolchain unavailability observed during sibling rebuilds (not worked around)",
      "exact_error": "/home/user/projects/npunlock-work/shave-toolchain-root/bin/moviCompile: 23: exec: /home/user/projects/llvm-14/build/bin/clang: Permission denied  (-> tool_failed at shavecc.compile); the identical commands succeeded once the sibling's llvm-14 rebuild finished"
    }
  ],
  "peer_handoffs": [
    "MultiOpProbe: verified the shipped script independently and matched contracts/timings.",
    "KernelLib: 2-input Maximum carriers (1x1024 -> 256 f16/invocation, 1x16384 -> 4096) generated on request + the checked-in IR fixture + exact commands.",
    "GGMLBackend-2/3: measured tile mapping (contiguous E=N/2 windows, per-invocation in/out windowing, 2 of 4 targets load-bearing), and a bit-exact working wide binary add including their exact XOR-cast expression (theirs failed only in their own 996 B build: fmt=2 injection and/or frozen snapshot toolchain).",
    "NPURuntime: carrier paths for its session benchmarks; no interface change to include/npunlock/* or level_zero_min.h.",
    "CorpusWave2: codegen data points (multi-store no-op still present on wide carriers after their fix, FrameIndex gap confirmed)."
  ]
}