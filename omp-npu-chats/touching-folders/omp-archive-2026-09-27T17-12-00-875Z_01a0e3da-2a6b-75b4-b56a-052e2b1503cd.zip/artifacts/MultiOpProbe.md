{
  "status": "complete",
  "report": "/home/user/projects/npunlock-work/multiop/REPORT.md (398 lines, incl. §6 addendum)",
  "answers": {
    "1_carrier_ceiling": "REFUTED. Patchable carriers of arbitrary 1xN f16 shape are obtainable on Linux: (a) my out-of-tree `multiop/work/ircompile` (ZeGraphCreate2 NGRAPH_LITE + GetNative2) compiles an OpenVINO IR in 0.13-0.41 s, and (b) PosixWorker's shipped `npunlock_worker` / npu_carrier_smoke.sh now does the same in-tree. Measured tile sizes: 8 f16/invocation (abs-add-1x16), 16 (abs-abs-1x32), and 512/1024/2048/4096/8192 f16/invocation for IR Abs carriers at N=1024/2048/4096/8192/16384 — all patched outputs verified element-exact. Carrier menu measured by op: ACT-patchable Abs, Elu, Erf, Sigmoid, Exp, Floor, Log, Sign, Sqrt, Tanh, Maximum, Minimum, Power, Divide (the last four 2-input); DPU-only (not patchable) Add, Clamp, Multiply, Relu, Subtract.",
    "2_multi_kernel_per_invocation": "YES. Rewriting the per-range RELA addend + extent (12 bytes) after patchblob gives each ACT range its own entry point inside one appended image. Proven: 2 distinct kernels on abs-add-1x16-tile1 (bit-exact vs host double oracle, 3/3 byte-identical), 4 distinct kernels on abs-abs-1x32 (load-bearing ranges 0/2/4/6, exact +2/+4/+6/+7 deltas, chained groups serialised, tiles parallel), 2 distinct on the IR 4-target carriers (ranges 0/2 load-bearing, 1/3 inert). NEW measured rule: the range code address is rounded down to a 0x400-byte boundary, so entries must be 0x400 apart.",
    "3_host_cost_and_elements_per_s": "One fresh call (create+initialize+first execute) = 22.9-55.4 ms, nearly independent of tile size; re-executing a live graph = 0.14-0.5 ms. This brackets the backend's 19.4/46/48 ms. Elements/s: warm 149k (N=32) -> 7.1M (N=1024) -> 17.0M (N=4096) -> 77.4M (N=16384); fresh-graph 670 / 31k / 80k / 385k. Pipeline: patchblob 3-23 ms, porting_probe create ~180 ms, verify ~62 ms, linux-probe ~29 ms, IR compile 130-330 ms cold / 5-15 ms cached.",
    "4_if_multi_kernel_not_possible": "N/A — it is possible; the measured limits are 2 load-bearing ranges (abs-add-1x16, IR Abs carriers) and 4 (abs-abs-1x32)."
  },
  "cross_check": {
    "shipped_path": "npunlock/tools/npu_carrier_smoke.sh --elements 4096 -> exit 0, 7/7 stages, oracle exact; carrier-1x4096.blob contract (4 targets, 2048 f16/invocation, span 4096 B, fp16) identical to mine; warm exec 0.232 ms vs my 0.241 ms.",
    "peer_notified": "agent://PosixWorker"
  },
  "reproducibility": "Timings = median of 3 x 50 executions; 2-kernel result re-run 3x byte-identical; routing maps re-run 2x each; every sweep output checked element-by-element (all == in+1.0).",
  "caveats": [
    "create2 returns in ~0.1 ms (lazy); the fresh-cycle figure is the sum create+init+first-exec.",
    "0x400 rounding measured on 4 carriers, not swept against tile size.",
    "Inert ranges accept code pointers but never affect graph output; their execution is not observable and is not claimed.",
    "abs-abs group routing derived by perturbation, not from driver source."
  ]
}