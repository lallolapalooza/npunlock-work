{
  "acceptance_gate": {
    "command": "cd /home/user/projects/npunlock-work/npunlock && ./tools/npu_add1_smoke.sh --elf <ours.elf>",
    "oracle": "fp16_carrier_add1_exact — ACTUAL == EXPECT byte-for-byte (32/32): 00 c3 bc bd e0 b5 68 32 22 3a 55 3c 9a 3d de 3f 11 42 1a 44 2b 45 9e 48 53 4c 2c 50 17 54 0c 58",
    "reproducibility": "3/3 shell-invoked runs from my own clean `ninja -C build llc clang` after ResultingBear's commit, each with a fresh build directory",
    "result": "rc=0 (GREEN)",
    "stages": "loader/device/graph-create/initialization/execution all PASS, oracle PASS"
  },
  "final_backend_rules": [
    "all conditional branches emit `.byte 0x1b, 0x40` — the descriptor byte selects the branch SENSE (`1b 40` taken iff the CMU source == 0), direction irrelevant; paired with `getSetCCInverse` in LowerBR_CC so guards and loop backedges both take the intended sense",
    "load write-back window: gap counting excludes LSU instructions (incl. LDIL/LDIH), the next LSU op is pushed past the window, +1 slot for `LD.32.F16.F32`",
    "LDI constant pair: padding to its own first consumer and to the next LSU op (the LDI family shares the 6-slot latency bucket)",
    "`SAU.DIV.U32`: 13 slots to its first reader (all five sites verified padded)",
    "`SAU.ADD.F32`: 3 slots (ResultingBear's `fixFAddLatency`)"
  ],
  "gates": {
    "gated_ctest_shave_add1": "RED — byte-compare class (1124 vs 828 B), accepted per the task definition",
    "offline_ctest": "cd npunlock/build/fresh && ctest -> 100% tests passed, 15/15",
    "structure": "iter_compare.sh structure gate (npunlock_parse_shave_elf) PASSED, .text 496 B vs gold 192 B (2.58x)"
  },
  "handover": {
    "landed_by_ResultingBear": "`FADD_F32_ONE` = `SAU.ADD.F32 $dst,$src,i1` (the third operand is the hardware's constant selector, so the 1.0f LDI pair disappears), ISel selection for fadd(x,1.0f), and `fixFAddLatency` (default 3). My all-`1b 40` descriptor choice is unchanged and confirmed correct by their kernel-level A/B (`2b 40` on the fp backedge exits after one iteration).",
    "next": "arbitrary-C corpus list Main published (calls -> int<->float -> div/mod -> globals/br_jt -> frames/spills); the add1-fp16 acceptance gate is closed."
  },
  "my_contributions": [
    "new post-RA legality pass `SHAVEFillDelaySlots.cpp` (registered at addPreEmitPass2) implementing the descriptor sense, the load write-back window, LDI-pair spacing, DIV padding, with cl::opt tunables and per-rule disable switches",
    "identifier/ISel: SETCC32 rewritten for the CMU flag protocol (unsigned + signed via sign-flip and division formulations, since the hardware has no ordered compare) and `getSetCCInverse` restored in LowerBR_CC — together these fixed the guard/loop control flow (peer-verified: count = 8, guards correct, first fp16 store landing a real value)",
    "`SHAVEInstrInfo.td`: NOP, BR_DELAY/BR_DELAY_BWD, `LSU0.LDIL ; fmt=0` (4-byte form), f16 store on LSU1; `SHAVEAsmPrinter.cpp` bundle-aware emission; `SHAVETargetMachine.cpp` wiring",
    "fixed the signed-compare regression I introduced (r62_signed_relational.c and a02_add1_fp16_header.c compile and assemble clean again, offline ctest 15/15)",
    "hardware measurements: descriptor sense/direction table, CMU flag protocol (CMZ/CMII/CMVV/CMIIABS all `!=`), LDIL+LDIH→LSU fault rule, SAU.DIV 13-slot latency, ALU latency 0, the carrier-init baseline, and the probe-hygiene rule about high registers",
    "two of my own earlier claims retracted in the log after controlling for carrier-init and high-register artifacts (the offset-0 LDO 'defect' and the 'one element written'/'count = 0' readings)"
  ],
  "status": "COMPLETE — the add1-fp16 oracle gate passes (rc=0) with ACTUAL == EXPECT; structure gate PASSED; offline ctest 15/15; gated byte-compare RED as accepted.",
  "text_size": {
    "gold": 192,
    "ours": 496,
    "ratio": "2.58x"
  }
}