{
  "status": "complete",
  "repo": "/home/user/projects/npunlock-work/npunlock",
  "acceptance": {
    "fresh_linux_build_default_ctest": "14/14 GREEN (porting_*, common, api_contract, shave_elf_parser, graph_blob_rejection, cli_version, cli_help, python_api, patchblob_shared_add1, native_shave_stage); full configure/build/ctest outputs pasted into BUILD_REPORT.md",
    "api_contract_python_api_pass": true,
    "native_stage_tests": "ctest native_shave_stage covers success (exact stdout passthrough), stderr->diagnostic+TOOL_FAILED(exit 3), missing root->NOT_FOUND with 'not_found' in diagnostic, deadline->SIGKILL+TOOL_FAILED within bound, link temp staging with zero npunlock-* files left in TMPDIR, plus end-to-end shavecc pipeline reproducing the 828-byte gold ELF byte-for-byte against the staged fixture toolchain",
    "gated_gold_test": "shave_add1 compiles on Linux, stays expected-RED (env unset, no real toolchain yet); default suite never registers it; recorded in BUILD_REPORT.md",
    "no_wine_dll": "Linux path uses posix_spawn only; movi_stage_win32.c, worker_process_win32.c, session_win32.c, src/workers/* and npunlock_worker remain if(WIN32); no dlopen/wine anywhere in shavecc path"
  },
  "key_files": [
    "src/shavecc/movi_stage_native.c (new POSIX stage: argv[0]=exe path, stdin=input buffer, stdout=result, stderr->stdout_log+stderr_log and ->diagnostic on failure, 64MiB message/32MiB result caps per movi_protocol.h, waitpid deadline -> group SIGKILL -> TOOL_FAILED, TMPDIR link staging with FD_CLOEXEC mkstemp + unlink on every path)",
    "src/shavecc/movi_stage.h (seam docs + NPUNLOCK_MOVI_SCRIPT_SENTINEL/OBJECT_SENTINEL)",
    "src/shavecc/shavecc.c (bin/moviCompile|moviAsm|moviLLD|lib/mlibm.a on POSIX, argv[0]=exe path, POSIX-absolute accepted while C:\\ still valid, -T <script> <object> -o - tail, mlibm linked only if present, portable separator; embedded script/header expansion untouched)",
    "src/graphinfer/session_posix.c (new: validation parity with Windows + honest NOT_IMPLEMENTED for Level-Zero work; points to src/linux_probe)",
    "CMakeLists.txt (return() removed; Linux builds npunlock_shavecc_objects+npunlock_native+npurun+all tests; merged NPUNLOCK_FORMAT_SOURCES+single format targets; fixture exec-bit CHMOD)",
    "tests/unit/test_movi_stage_native.c + tests/fixtures/fake_shave_toolchain/{moviCompile,moviAsm,moviLLD} (marked test infrastructure)",
    "renames: NPUNLOCK_ENABLE_SHAVE_TOOLCHAIN_TESTS (CMake+ci.yml+release.yml), NPUNLOCK_SHAVE_TOOLCHAIN_DIR (npurun/python/tests), toolchain_directory_utf8 (header/ctypes/C_API/npurun), toolchain_dir kwarg (python+examples), --toolchain-dir (npurun), ctest shave_add1",
    "docs: wiki/GET_SHAVE_TOOLCHAIN.md (new, under-construction build section, no invented commands, r2gvp04w/RE provenance; GET_MOVITOOLS.md removed), wiki index, README (only claims made false), docs/C_API.md, ABI/MOVITOOLS.md top section 'Replaced by native SHAVE toolchain' (no-temp-files claim retired to DLL flow), DEVELOPMENT/PYTHON_API/LIMITATIONS/PORTING/CUSTOM_KERNELS/HOW_NPUNLOCK_WORKS/MODEL_TO_MACHINE_CODE etc.",
    "BUILD_REPORT.md (commands + full outputs, rename table, design notes, what-changed-in-docs, limitations)"
  ],
  "decisions": [
    "Streams: stdout->result.output; stderr->stdout_log AND stderr_log (task literal 'stderr=stdout_log' plus existing warning/error consumers); on failure stderr (<=65535) -> diagnostic",
    "Timeout status = TOOL_FAILED per task wording (not TIMEOUT)",
    "ir_worker_win32.c is portable C (no Windows headers) and now compiles on Linux - required to link ir2blob_compile for api_contract; it spawns via worker_process.h (POSIX launcher), never dlopens; the truly Windows-only worker/ir2blob/graph code stays gated",
    "graphinfer POSIX sessions report NOT_IMPLEMENTED for real work (capability boundary documented in BUILD_REPORT; no fake success)",
    "worker_executable_utf8/--movi-worker/movi_worker= keep names: they are npunlock's own Windows worker, not the removed vendor path"
  ],
  "caveats": [
    "shave_add1 stays red until stream B's real toolchain lands",
    "clang-format and black not installed locally: format-check/black --check not executed (code written to .clang-format LLVM/2-space/100-col and Black conventions by inspection)",
    "Python wheel build not exercised on Linux; python_api passes without loading libnpunlock.so",
    "Changes left uncommitted in the working tree (32 modified, 6 new paths incl. BUILD_REPORT.md) for main-agent review"
  ],
  "verification": {
    "commands": [
      "cmake -S . -B build/fresh -DCMAKE_BUILD_TYPE=Release -DNPUNLOCK_BUILD_TESTS=ON -DNPUNLOCK_ENABLE_SHAVE_TOOLCHAIN_TESTS=OFF ...",
      "cmake --build build/fresh -j12 (0 warnings under -Wall -Wextra -Werror -Wpedantic)",
      "ctest --test-dir build/fresh --output-on-failure -> 100% tests passed, 0 tests failed out of 14"
    ]
  }
}