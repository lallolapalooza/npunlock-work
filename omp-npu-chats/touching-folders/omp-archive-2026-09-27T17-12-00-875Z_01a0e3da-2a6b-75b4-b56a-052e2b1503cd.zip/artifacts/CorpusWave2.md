{
  "artifacts": {
    "FINDINGS": "/home/user/projects/npunlock-work/FINDINGS.md (386 lines; two new measured rules + the open defect)",
    "probes": "/home/user/projects/npunlock-work/corpus-w2-probes/ (24 files, 88 KB)",
    "new_repro_sha256": {
      "mhi.c": "96101d1478b1ce0f9cfab427aef36ff690034ff0fc9d2714936a75eaf0a5f49f",
      "mdiv.c": "ce30a551d22394d952e229dcf28b4e69b44a811327c6cbbc327e052c7a6a0cf2",
      "mk0.s": "5d5b2585eed98b02d457323bc15b94258ec0cb6930f75b07a225b6a24074191d",
      "mk1.s": "6c4bf275d3bc1cc897fea8a4547893e352f84516be8e3e86b52d2f88fd6f6253",
      "mlo.c": "18bc508d535b47db232b127ddd2bc5b412ec3213af230c8548ac08a33e60ae27",
      "mulh.c": "915653ad81128421d226e836cd39c52edab0ac261452cfca9ba1445b43fdfa4e"
    }
  },
  "caveat": "Numeric hardware verification this run covers ONLY a05_scale_f32 and l01_silu_f32. Every other PASS is the structural validator, and the integer kernels are now known-suspect.",
  "corpus": "27/33 (structural validator: compile+assemble+link+validate)",
  "invariants": "npu_add1_smoke.sh --elf ../our-add1-fp16.elf -> exit 0, oracle exact (driver_index=0, device_id=32029); ctest --test-dir npunlock/build/fresh -> 100% passed, 0 failed (16 tests). Verified after every landed edit.",
  "landed_and_verified": [
    "Call-preserved mask corrected to the measured set i12..i16,i19,i20..i29,i31 (word0 0x7FF3E000, word1 1); i11 measured NOT preserved by mlibm expf despite the vendor DWARF CIE; l01 output byte-identical to its verified baseline.",
    "i31 added to GPR/GPRF32/GPRF16 (it is bit 32 of the mask); GPRF16 spill size pinned to 32 bits (TableGen had inferred 16).",
    "LowerFormalArguments now uses getCopyFromReg instead of a bare $r18, and R18 is no longer reserved: this was a silent miscompile for any layerParams live across a call (repro kernel wrote nothing; now exact).",
    "f32 arithmetic: FADD/FSUB/FMUL pin '; fmt=2' on SAU (fmt=3 makes operand 3 a hardware constant SELECTOR keyed by the register NUMBER; VAU.MUL/SUB never write their destination). MUL/SUB also need the 3-slot result latency. a05_scale_f32 is now BIT-EXACT against an IEEE-float32 oracle.",
    "int<->float conversions (4 byte-exact vendor forms) + FSQRT/FPOW/FSIN/FCOS/FSINCOS/FEXP/FEXP2/FLOG/FLOG2/FLOG10 as mlibm libcalls: l02_rms_norm_f32 now PASSes; b03/b10/b12 too.",
    "f32 value-select (SELECT_F32/F16) + fp compare lowering via a monotone IEEE key, unblocking b16_fcmp/l03_softmax_f32 to structural PASS.",
    "NEW measured rule: IAU.MUL needs >=1 filler slot (k=0 stores a stale/zero register, k>=1 correct). Landed as -shave-mul-latency=2 in SHAVEFillDelaySlots.",
    "Spill failures now report_fatal_error instead of llvm_unreachable (turns an opaque SIGABRT into a one-line diagnostic; this was a crash class I introduced by moving l05 past ISel)."
  ],
  "landed_but_UNVERIFIED": [
    "LowerMULHU 16x16 partial-product decomposition (required because IAU.LMULH was measured bad).",
    "fp-compare numerics (b16_fcmp / l03_softmax_f32 are structural-only).",
    "b01_int_arith numbers - now known-suspect, see open defect."
  ],
  "not_done_stopped_per_instruction": [
    "Item 1 (fp16 lane loss): could not be reproduced; the 'missing aliased-store pad' hypothesis I filed is DISPROVEN (padding 0/1/2/4 slots changes nothing), and my first repro was a probe artifact of my own hand-written loop. No fix to verify against. Best candidate mechanism is now the integer-multiply defect below.",
    "The integer-multiply defect itself (undiagnosed, see below).",
    "Item 3 remainder: SDIV Legal / SDIVREM+UDIVREM custom + LowerDivRem, MULHS, ctlz/cttz/ctpop/bswap/fabs.",
    "Item 4: GlobalAddress selection + dropping the false ISD::BRIND=Custom claim.",
    "Item 5: frame/spill lowering on SP=i19."
  ],
  "open_defect_handed_over": {
    "detail": "Compiler-generated integer multiply is still WRONG even with the IAU.MUL fillers. out[0]=a*b returns 0x2e014004 and ((unsigned long long)a*b)>>32 returns 0x02738083, where the oracle (a=0xc0dec480, b=0xba66bd78) is 0x2a7e9c00 / 0x8c6f4246. out[1]=a and out[2]=b are exact and 0xFFFFFFFFu/(a|1u) is exactly 1, so operands and the division path are fine. This is a SECOND defect beyond latency.",
    "impact": "b01_int_arith and every integer kernel that multiplies, LowerMULHU, and the mulhu-dependent constant-division path behind the fp-compare NaN test (b16_fcmp, l03_softmax_f32) must be treated as structural-PASS only and numerically suspect. This also supersedes any earlier implication that the integer path was sound.",
    "likely_third_party_impact": "This is the best available explanation for GGMLBackend-3's 'a few percent of fp16 lanes never written at irregular indices' - their kernels derive loop bounds/address steps from integer multiplies, and a stale product gives a wrong/unstable bound. Told them to grep their .s for an IAU.MUL whose consumer is within 1 slot.",
    "repro": "corpus-w2-probes/{mulh.c,mlo.c,mhi.c,mdiv.c} through llvm-14/tmpdump/runp3.sh <file> --tag <t>"
  },
  "recommendation_for_next_agent": "Chase the integer-multiply defect first: it is silent, it is in a primitive that mulhu/magic-number division/every integer kernel depend on, and the repro is two lines and already on disk. Item 4 (GlobalAddress) is cheap and independent if coverage is preferred over correctness.",
  "scratch_policy": "Compliant: TMPDIR=/var/tmp/npu-scratch, own subdir created. My /tmp footprint peaked at 76 MB and is now zero; the remaining /tmp pressure belongs to /tmp/prebuilt3720 and /tmp/opencode, which I did not touch."
}