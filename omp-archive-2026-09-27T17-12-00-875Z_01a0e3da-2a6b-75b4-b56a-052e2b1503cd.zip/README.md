# Session archive

Generated 2026-10-04T21:08:48.908Z from session `01a0e3da-2a6b-75b4-b56a-052e2b1503cd`.

## Layout

| Path | Contents |
| --- | --- |
| `manifest.json` | Index of everything below (counts, sizes, subagent list) |
| `session.jsonl` | The main session transcript, verbatim |
| `agents.json` | Live per-agent state captured while the session ran (model, system prompt, tools) |
| `jobs.json` | Background jobs: `completed` (recovered from transcripts) + `live` (running/recent at archive time) |
| `artifacts/` | Every file under the session artifact directory, verbatim |
| `viewer.html` | Standalone HTML viewer (all subagent sessions embedded) |

`artifacts/` is the important part: it holds each subagent's own
`<AgentId>.jsonl` transcript (recursively nested), the session's
`*.bash.log` / `*.eval.log` / `*.read.log` files with the **full, untruncated**
tool and background-job output, and `*.jsonl.tombstone` kill markers.

## Background jobs

384 completed jobs recovered from the transcripts (main + every subagent); full list in `jobs.json`. A live snapshot of running/recent jobs for Main is also included. Per-job output lives in the owning transcript and in `artifacts/*.log`.

## Subagents (54)

- `AsmEncodingRE` — 1798 entries, 6591384 bytes
- `AsmObjWriter` — 329 entries, 1694567 bytes
- `AsmSchedImpl` — 912 entries, 3684860 bytes
- `BiologicalMockingbird` — 621 entries, 2741840 bytes
- `CorpusProbe` — 426 entries, 1320166 bytes
- `CorpusWave1` — 336 entries, 1517525 bytes
- `CorpusWave1-2` — 706 entries, 2462831 bytes
- `CorpusWave2` — 779 entries, 2749989 bytes
- `CuteDragonfly` — 303 entries, 1342756 bytes
- `EffectiveUrial` — 188 entries, 1048558 bytes
- `EvalHarness` — 405 entries, 1913085 bytes
- `EvalHarness-2` — 858 entries, 3212797 bytes
- `GapCalls` — 270 entries, 1244249 bytes
- `GapCalls-2` — 427 entries, 2066872 bytes
- `GapCasts` — 308 entries, 1130758 bytes
- `GapCasts-2` — 307 entries, 1509934 bytes
- `GapDivBuiltins` — 317 entries, 892251 bytes
- `GapDivBuiltins-2` — 388 entries, 1387479 bytes
- `GapGlobalsFrames` — 328 entries, 1319820 bytes
- `GapGlobalsFrames-2` — 363 entries, 1749263 bytes
- `GGMLBackend` — 328 entries, 1106790 bytes
- `GGMLBackend-2` — 828 entries, 3580876 bytes
- `GGMLBackend-2/GGMLBackend-2.NpuExecScout` — 172 entries, 1459014 bytes
- `GGMLBackend-3` — 590 entries, 2215892 bytes
- `GGMLBackend-4` — 651 entries, 2571802 bytes
- `HeavyDemo` — 90 entries, 329460 bytes (killed)
- `InternationalUrial` — 642 entries, 2013206 bytes
- `IntMulFix` — 665 entries, 2181261 bytes
- `KernelLib` — 737 entries, 2850711 bytes
- `LinkerRelocRE` — 503 entries, 1713631 bytes
- `LlamaKernels` — 184 entries, 706765 bytes
- `LLVMShaveBackend` — 1468 entries, 4397773 bytes
- `MathLink` — 611 entries, 1708333 bytes
- `MedicalCrayfish` — 924 entries, 3539077 bytes
- `MultiOpProbe` — 501 entries, 2009599 bytes
- `NpunlockNativeStage` — 537 entries, 2186982 bytes
- `NPURuntime` — 702 entries, 2807518 bytes
- `OVDemo` — 280 entries, 776042 bytes
- `PleasedDog` — 1938 entries, 6219332 bytes
- `PleasedSloth` — 679 entries, 1911912 bytes
- `PosixWorker` — 687 entries, 2474097 bytes
- `ResultingBear` — 332 entries, 1764599 bytes
- `RoughFinch` — 657 entries, 2768770 bytes
- `ScoutLLVMHistory` — 132 entries, 402279 bytes
- `ScoutNpunlock` — 168 entries, 803663 bytes
- `ScoutRERepo` — 184 entries, 462299 bytes
- `ScoutWebSHAVE` — 334 entries, 649364 bytes
- `SDPort` — 99 entries, 209659 bytes (killed)
- `SeparateMockingbird` — 667 entries, 2418199 bytes
- `StatutoryWhitefish` — 328 entries, 1005858 bytes
- `StrangeSole` — 558 entries, 1895552 bytes
- `ThoughtlessBison` — 560 entries, 1781828 bytes
- `ToolchainBuild` — 317 entries, 860441 bytes
- `VendorRE2` — 579 entries, 2611849 bytes

## Totals

333 files, 290177622 bytes.
