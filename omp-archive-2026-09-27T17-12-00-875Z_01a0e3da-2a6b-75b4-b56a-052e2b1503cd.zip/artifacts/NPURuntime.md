{
  "deliverable": "/home/asdf/projects/npunlock-work/npu-runtime/ — `libnpu_runtime.{a,so}` + `include/npu_runtime.h` (public API), `README.md` (API/build/usage/measured numbers/limits), copyable example (`examples/backend_example.c`), 6 diagnostic tools, and `make check` (15-check acceptance suite). Nothing outside this directory was written or modified (verified).",
  "headline": {
    "per_invocation_reused_session_16elem": "0.95–1.00 ms median, 0.79–0.91 ms min (999 invocations/s, 16 k elements/s)",
    "per_invocation_reused_session_32elem_ggml_carrier": "1.21 ms (829 invocations/s, 26.5 k elements/s)",
    "per_invocation_reused_session_2048elem": "1.145–1.165 ms (858–873 invocations/s, 1.76–1.79 M elements/s)",
    "batched_marginal_per_execution": "0.38–0.48 ms (flat from 16 to 2048 elements) = 5.1 M elements/s at 2048 elements",
    "no_reuse_median": "22.7 ms idle host / 31–47 ms loaded (--recreate, same process) vs 46 ms for the shipped engine path (ggml-shave README)",
    "naive_cli_flow": "1045–1353 ms per call end to end (median stage split below)",
    "speedup": "≈23–46x vs graph-recreation paths; ≈1000x vs the full CLI flow; batching adds another 2.1–2.5x"
  },
  "per_kernel_vs_per_invocation": {
    "per_kernel (cached by SHA-256 of the patched blob)": [
      "moviCompile+moviAsm+moviLLD: 137+639+140 ms (only if compiling from source)",
      "patchblob carrier+ELF→blob: 3.7–19 ms",
      "porting_probe create/verify: 133–230 ms — not used by the runtime at all (bundle files are not needed to execute)",
      "zeGraphCreate2: 0.06–0.30 ms",
      "argument query + host allocations: 0.2–1.3 ms",
      "zeGraphInitialize: 1.8–8.9 ms",
      "warm() (loader+device+context+queue group): 3–6 ms, once per process"
    ],
    "per_invocation": [
      "copy input + reset output + bind args: <0.01 ms",
      "cached command list re-submit (zeCommandQueueExecuteCommandLists): 0.01–0.08 ms",
      "fresh fence create/destroy: ~0.08 ms",
      "fence wait (device execution + completion): 0.80 ms @16 elements, 1.12 ms @2048 elements"
    ],
    "setup_total": "6.2–25.9 ms per kernel (amortised after ~25 invocations)"
  },
  "api": {
    "lifecycle": [
      "npurt_config_defaults / npurt_configure (paths, timeouts, cache size, toolchain, carrier, entry symbol, link libs)",
      "npurt_warm() / npurt_is_warm() / npurt_shutdown()",
      "npurt_compile_source(src,len,&elf,&sz) — moviCompile→moviAsm→moviLLD via fork/exec, no shell, per-stage timeout"
    ],
    "kernel": [
      "npurt_kernel_create(elf,size,&k) — patches, loads, initializes, caches by kernel hash (blob sha256 + elf sha256 fast path)",
      "npurt_kernel_create_from_blob(blob,size,&k) — loads an already patched graph (ggml-shave's build-time path)",
      "npurt_kernel_create_layered(entries[],n,&k) — several ACT groups of one carrier patched with different ELFs",
      "npurt_kernel_lookup / npurt_kernel_info_get (hashes, shapes, stage timings, run count) / npurt_kernel_free / npurt_cache_stats_get"
    ],
    "invocation": [
      "npurt_run(k,&req,&timing,&diag) — request = {input,input_size,output,output_size,dims,dims_count,timeout_ns}; timing = prepare/session/submit/wait/teardown/total/run_index",
      "npurt_kernel_clone(k,&clone) + npurt_run_batch(kernels[],requests[],n,&timing) — N invocations in one submission, one wait, each handle with its own buffers"
    ],
    "errors": "NPURT_ERR_{ARGUMENT,STATE,IO,COMPILE,PATCH,DEVICE,NO_NPU,TIMEOUT,SHAPE,NOT_FOUND,UNSUPPORTED,OUT_OF_MEMORY} + a 512-byte diagnostic string"
  },
  "verified_evidence": {
    "acceptance": "`make check` (tools/run_checks.sh) from a clean build: CHECKS PASS 0 failures — build warning-free; semantic add-one oracle 3/3 runs; example compile-from-source + exact oracle; cross-validation vs dump_probe; multi-kernel handles; batch bit-identical; 2048-element carrier; session lifecycle; fence-timeout reporting+recovery; 4-thread and 2-process concurrency; reuse regression guard",
    "independent_ground_truth": "corpus a05_scale_f32 compiled by the runtime produced byte-identical output to `llvm-14/tmpdump/dump_probe --bundle` ACTUAL (both sides derived at check time, survives toolchain rebuilds), and repeated invocations were bit-identical",
    "semantics": "fixture add1 kernel: ACTUAL == exact fp16 add-one oracle (carrier ramp modelled), bit-exact over 3 invocations",
    "cross_carriers": "four carriers exercised: npunlock abs-add-1x16-tile1 (16 el), abs-abs-1x32 (32 el, ggml-shave prebuilt kernel), multiop IR g2048_add1.blob (2048 el), plus the gold fixture ELF"
  },
  "device_findings": {
    "session_teardown": "Destroying the Level Zero context and re-initialising the driver in one process makes the next submit SIGSEGV inside libze_loader.so.1 (dlclose does not help). The loader/device/context are therefore process-lifetime; npurt_shutdown() releases kernels + queue and npurt_warm() re-arms the same session (5/5 clean, tools/session_probe.c).",
    "fence_reuse": "zeFenceHostSynchronize on a fence already signalled by the previous submission returns before the new invocation completed — measured directly: every second repeat read the reset (0x7e00) output window. Command list reuse is safe; fences are created fresh per submission.",
    "timeout": "a 100 us fence timeout returns NPURT_ERR_TIMEOUT (0x00000001) and the session keeps working (19/19 subsequent runs passed) — retry is safe.",
    "hung_kernel": "a non-terminating kernel (corpus a01/a02) can exceed the fence timeout and then poison subsequent submissions in that process with 0x70000001 ZE_RESULT_ERROR_DEVICE_LOST; a fresh process recovers immediately (verified). Keep timeouts short, restart the process on timeout.",
    "multi_process": "two processes sharing /dev/accel0 both complete with no errors; each gets ~457 calls/s (2.19 ms/call) vs ~970 solo — time-shared, no corruption.",
    "threads": "4 threads x 50 calls, 0 failures, 1.05–1.9 ms/call (one global mutex, single-thread queue semantics)."
  },
  "adoption_for_ggml_backend": {
    "backend_init": "npurt_config_defaults + npurt_configure + npurt_warm (≈3–6 ms, once)",
    "op_install": "npurt_kernel_create_from_blob(shave-kernels.inc patched graph) or npurt_kernel_create(ELF) once per op/shape; ≈0.015 ms when cached",
    "graph_compute": "npurt_run with the node's tile — measured 1.0 ms (16 el) / 1.21 ms (32 el) / 1.15 ms (2048 el) instead of 46 ms",
    "optional": "npurt_kernel_clone + npurt_run_batch to overlap several tiles per submission (2.1–2.5x)",
    "note": "shave-runner.c's per-request process/pipe round trip is no longer needed; if kept, it should hold the npurt_kernel* for the process lifetime."
  },
  "offload_economics": {
    "measured_elements_per_second": {
      "16 f16": "15.7 k serialized / ~40 k batched",
      "32 f16": "26.5 k / ~79 k",
      "2048 f16": "1.76 M / 5.1 M",
      "8192 f16": "[INFERENCE] ~7 M / ~20 M"
    },
    "conclusion": "per-op offload with today's 32-element carrier is not viable (26 k elements/s); with a ≥2048-element tile it reaches 1.8–5.1 M elements/s, which makes elementwise offload worth evaluating. The two prerequisites (wide carriers, working arithmetic kernels) are outside this directory and are being worked by PosixWorker/multiop and KernelLib.",
    "reconciliation": "multiop's 0.14–0.5 ms 'warm execute' and 77 M elements/s at 16 384 elements come from a fence-reusing loop, which on this driver can return before completion (see fence_reuse) — that measures submission rate, not completion. It matches my batched numbers (0.38–0.48 ms/exec, completion-correct), not my serialized ones."
  },
  "limits_documented": [
    "static shapes (buffer sizes + optional dims asserted against the driver's graph tensors, NPURT_ERR_SHAPE on mismatch)",
    "invocation-local memory only; exactly one input and one output tensor per graph",
    "session is process-lifetime (no device teardown, no recovery from DEVICE_LOST except a new process)",
    "copies in/out per call (<1 us for 32 B, ~4 us for a 4 KB tile); no zero-copy API",
    "one global mutex (thread-safe but serialized); cache never destroys a live handle (soft limit + warning)",
    "carrier .blob is an input; the runtime does not build graphs"
  ],
  "coordination": [
    "PosixWorker: told them my only interface dependencies on npunlock (libnpunlock patchblob symbols, level_zero_min.h) and asked for wide-tile carrier blob paths; sent the 2048-element numbers and the fence-reuse caveat",
    "KernelLib: sent the layered/multi-group and from_blob APIs, asked for ELF paths, entry symbols, group indices and mlibm linkage",
    "Non-blocking note: my compile-dependent checks briefly failed while llvm-14's clang was mid-rebuild ('Permission denied'); they pass again after the rebuild — the cross-validation check now derives ground truth at run time for exactly this reason"
  ]
}