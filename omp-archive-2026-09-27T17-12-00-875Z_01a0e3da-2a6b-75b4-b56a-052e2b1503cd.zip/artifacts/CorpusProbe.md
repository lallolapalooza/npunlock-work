{
  "headline": {
    "kernel_corpus": "13/33 pass (compile+assemble+link+structural validation); 20 fail, 2 of the 20 are the deliberate missing-entry linker probes",
    "minimal_repros": "15/62 pass",
    "revision": "primary dataset = pinned snapshot clang sha256 f590201d… / shave_asm.py bc43eaa4… (snapshot A, 13:01). Revision C (2743c8c1…, 13:08) gives IDENTICAL pass/fail classification on all 95 units (only .text sizes differ, e.g. a01 384→432B). Revision B (925e96aa…, 13:04) is a WIP build that SIGABRTs on the baseline fixture itself.",
    "failure_taxonomy": "28 pass; 30 ISel `Cannot select`; 17 backend fatal (`report_fatal_error`); 16 calls-unsupported; 2 sigabrt crash; 2 bogus-linker-message. ZERO assembler rejections (22 distinct mnemonics emitted across all 89 compiling units), ZERO linker rejections apart from the 2 probes, ZERO structural-validation failures. No hangs.",
    "execution_axis": "Our a01 (structurally valid) runs on the NPU through stage `execution` but fails the oracle: ACTUAL contains guard constants (0x3f800000=1.0f, 0xbf000000=-0.5f) instead of sums (FINDINGS R4/R5). Gold control in the same session: exit 0, oracle exact."
  },
  "artifacts": {
    "report": "npunlock-work/corpus/REPORT.md",
    "defect_list": "corpus/DEFECTS.md (appended to REPORT.md verbatim)",
    "verbatim_diagnostics": "corpus/DIAGNOSTICS.md",
    "driver": "corpus/run_corpus.sh (--only/--dir/--tag/--timeout, honours NPUNLOCK_SHAVE_TOOLCHAIN_DIR)",
    "tools": [
      "corpus/tools/validate_elf.py (line-for-line reimpl of npunlock_parse_shave_elf; OK on gold and on ours)",
      "corpus/tools/make_snapshot.sh (pins clang/ld.lld/shave_asm/encodings/mlibm+REVISION.txt for reproducibility)",
      "corpus/tools/summarize.py",
      "corpus/tools/make_report.py (generates every table from the raw TSVs)"
    ],
    "kernels": "corpus/kernels/ 33 files (a01-a07 = verbatim repo fixtures/example strings incl. add1-fp16.c and all four examples/*.py kernels; b01-b26 = synthetic ISA coverage)",
    "repros": "corpus/repros/ 62 minimal one-construct files with .opts sidecars",
    "raw": "corpus/results_{kernels,repros}{,-b,-c}.tsv + corpus/logs/*.{compile,asm,link}.err + npu smoke/dump logs"
  },
  "top5_failure_classes": [
    {
      "class": "any function call",
      "msg": "fatal error: error in backend: SHAVE: calls are unsupported in wave 1 (callee GlobalAddress | ExternalSymbol | select)",
      "repro": "repros/r16_call_internal.c",
      "breadth": "16 units; all of lib/mlibm.a (tanhf), varargs, recursion, indirect calls, every i64/double libcall (__udivdi3, __divdi3, __floatundisf, __adddf3); ALL FOUR shipped examples/*.py kernels (a03,a04) fail here"
    },
    {
      "class": "signed relational compares",
      "msg": "fatal error: SHAVE: unsupported condition code 18/20/21 in wave 1 (floating-point and signed compares are unsupported)",
      "repro": "repros/r62_signed_relational.c, kernels/a02_add1_fp16_header.c",
      "breadth": "REGRESSION: the 12:53 build compiled a02/b06/r23; the 13:00+ builds reject them. Breaks npunlock's own include/npunlock/npu3720_kernel.h (__fixsfdi has `exponent < 0`), i.e. the documented include path no longer compiles"
    },
    {
      "class": "int<->float conversions",
      "msg": "Cannot select: t50: f32 = uint_to_fp t49 (also fp_to_uint, fp_to_sint, sint_to_fp)",
      "repro": "repros/r06..r09",
      "breadth": "b03, b10, b12, r46, r55 — any kernel mixing integer accumulators/indices with fp data"
    },
    {
      "class": "division/modulo lowering",
      "msg": "Cannot select: i32 = mulhu <x>, Constant:i32<-1431655765> (unsigned /,% by constant) and i32,i32 = sdivrem (signed /,%)",
      "repro": "repros/r01_udiv_by_const.c, r04_sdiv_i32.c",
      "breadth": "constant-folding of / and % fails while runtime-divisor udiv (r02, SAU.DIV.U32) works"
    },
    {
      "class": "global addresses / data sections",
      "msg": "Cannot select: i32 = GlobalAddress<@g_counter|@table|@switch.table…> 0; also br_jt CannotSelect",
      "repro": "repros/r12_global_var.c, r13_rodata_table.c, r10_jumptable_switch.c",
      "breadth": "all globals/static const tables and any switch big enough to become a jump table (b07, b18, r36)"
    }
  ],
  "other_classes": [
    "stack frames (FrameIndex fatal): local arrays with runtime index, 8-word struct copies, r47/r30/r14/b17",
    "register spills HARD CRASH: >=35 live values → UNREACHABLE at SHAVEInstrInfo.cpp:41 + SIGABRT (34 OK) — r61, r60",
    "FP compares (all predicates) + FP value-selects: r64, r15, r26, b16",
    "no ISel pattern for ctlz/cttz/ctpop/bswap/fabs: r49-r53, r45",
    "ld.lld reports `output file too large: 18446744073692774968 bytes` when the entry symbol is missing instead of `undefined symbol` (r42, r43)"
  ],
  "top3_fixes": [
    "1. Implement LowerCall + callee-save/return-address convention — one change unblocks the single largest group (helpers, all of mlibm.a, varargs, recursion, indirect calls, i64/double libcalls) and is a hard prerequisite for the repo's own examples.",
    "2. Fill the arithmetic/compare ISel surface: int<->float conversions, signed relational compares, mulhu/sdivrem, fcmp + FP value-selects. Cheap relative to (1) (DAG patterns/legalizations, no ABI design) and it is the surface ordinary C reaches in its first few lines. The signed-compare class is additionally a regression vs the 12:53 build.",
    "3. Give the target a memory model: global/data address materialization (also fixes jump tables) AND stack frames/spill slots, plus make the no-spill path impossible to reach (today 35 live values core-dump the compiler). Needed for every local array, global table and jump table."
  ],
  "caveats": [
    "Structural pass != correct execution; FINDINGS R2-R5 remain an independent, still-open blocker (proved by the a01 oracle failure above).",
    "The llvm-14 tree was being rebuilt during the measurement; all numbers come from pinned snapshots (corpus/toolchain-snapshot*) because one live run was corrupted mid-relink (`exec: …/clang: Permission denied`). Revision B (925e96aa) asserts in the brand-new pass `SHAVE issued-stream legality (load latency + branch delay slots)` on add1-fp16.c and should be re-measured, not actioned.",
    "No wine, no network; nothing outside corpus/ was written."
  ]
}