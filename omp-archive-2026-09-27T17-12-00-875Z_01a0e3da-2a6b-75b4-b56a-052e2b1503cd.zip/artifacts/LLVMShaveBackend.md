{
  "summary": "Wave-1 assignment COMPLETE and accepted; llvm-14 ownership transferred to PleasedDog per Main's stand-down. Final fresh gate run (in flight at stand-down) reconfirms: G1=0, G2=0 on the current tree.",
  "final_gate_status": {
    "gate1_add1_fp16": "exit 0, SAMPLE_OUTPUT.s = 300 lines, 15 BRU branches, contains SAU.DIV.U32 (gold-proven unsigned div) and BRU.JMP i30 (gold-proven epilogue)",
    "gate2_inline_header": "exit 0, SAMPLE_OUTPUT_INLINE_HEADER.s = 123 lines, 17 BRU branches (strtof/__truncdfsf2/__fixsfdi/controlled_act all emitted)",
    "llc": "llc --version lists 'shave - Movidius SHAVE'",
    "allocators": "greedy (default) and pbqp both complete add1-fp16 with the i30-reserved config"
  },
  "deliverables": {
    "in_tree": "clang SHAVE TargetInfo + llvm/lib/Target/SHAVE backend, build/ left in place, gates green",
    "docs": [
      "BUILD_FIXES.md (sparse-checkout/cstdint/cmake fixes)",
      "TARGET_NOTES.md (registers, ABI, dialect assumptions, unsupported-IR list, gate results, encoding gap 1682B vs gold 192B quantified)",
      "WAVE1_HANDOFF.md (append-only: SP findings, i30 reservation rationale, select-diamond CFG fix, encoder caveats)",
      "run_gates.sh"
    ],
    "samples": [
      "SAMPLE_OUTPUT.s",
      "SAMPLE_OUTPUT_INLINE_HEADER.s"
    ]
  },
  "key_findings_handoff": [
    "No SP/frame exists anywhere in corpus (gold+mlibm: zero frame ops, no LEA) - spill support deliberately left as loud error",
    "i30 must stay RESERVED: MachineVerifier seeds regsLive per-block from MBB.liveins only; non-entry allocatable live-ins banned (MachineVerifier.cpp:616-622);30 allocatable regs suffice post-fix",
    "Select-diamond custom inserter MUST transfer successors MBB->EndB and re-point successor PHIs; missing this caused the LiveVariables 'no reaching def' assert and inflated greedy spilling - documented for PleasedDog to keep",
    "AsmEncodingRE encode caveats recorded (LDIL fmt=100, BRA 1op/2op forms, [iN+off] 5B forms, CMU.CP/CMZ fmt hints, low-anchor mnemonics to verify vs gold; gold decode 70.3%, roundtrip 192/192)"
  ],
  "coordination": "Standalone instrumentation in LLVM core fully reverted; coordination messages exchanged with AsmEncodingRE (dialect verified: all emitted mnemonics present in encodings.json) and PleasedDog (ownership acknowledged, handoff delivered); no further llvm-14 edits from me.",
  "status": "STOPPED per Main stand-down"
}