{
  "status": "complete",
  "deliverables": {
    "packets/PACKET_SPEC.md": "~710 lines: packet/pipe model, annotated vendor functions with line cites, confidence table, open items, fix status, §5b corrected pattern-dependence (reconciled with the round-2 sibling §14), implementation guidance",
    "packets/VERIFIED_EXAMPLES.md": "~665 lines, Examples A-M: every claim with exact bytes + oracle transcripts; Example M is the full 43-prototype CV3600xx class sweep",
    "packets/probes/": "300+ probe sources incl. probes/cv/ (hardened sweep + index + raw results) and probes/br/ (sibling's), with reproduction recipes and the method traps documented"
  },
  "cv_class_sweep": {
    "method": "hardened skeleton validated by a control probe first (4 readback slots, precomputed address registers, 6x BRU.NOP fills, no filler/increment register); the first two attempts failed from my own address-chain arithmetic bug, caught by the control",
    "positive": [
      "0x82 LDIL -> 1",
      "0xa9 LSU1.LDIH -> high half",
      "0x81 CMU.CP.32 -> i2",
      "0xc6 IAU.ADD -> i2+1",
      "0x86 IAU.AND -> i2&i3",
      "0x46 IAU.BSF -> 14 = lowest set bit of the pointer",
      "0x3c SAU.MUL.I8 -> 0",
      "0x2c SAU.ABS.F32 -> |i2|",
      "0x1c SAU.SUMC -> 0xFFB1FFFF",
      "0x42/0x89/0xc2/0x49 load classes read memory",
      "0xfa LDO.32 fmt111 writes while f0/f9 leave the destination unchanged"
    ],
    "traps_not_absence_evidence": "0x04, 0x0a, 0x20, 0x47, 0xc5, 0xc7, 0xc8 (0x0a = the 3-byte LDIL-shaped form; 0x20 = ST.16.F32.F16, both corroborating earlier findings)",
    "neutral": "predicate-gated and store classes: 0x05, 0x08, 0x21, 0x22, 0x12, 0x13, 0x84, 0x85, 0x23, 0x33, 0x41, 0x70, 0x80, 0x92, 0xc4, 0xf0, 0xf9"
  },
  "core_rules_unchanged": [
    "LSU write->read >= 6 instruction slots",
    "LSU producer and consumer on different LSU units",
    "4-byte LDI forms (82|reg<<3|2 lo16, 82|reg<<3|3 hi16, a9|reg<<3|3 hi16); LDIL(lo)+LSU1.LDIH(hi) handles any 16-bit immediate",
    "verified load->ALU->store chain",
    "legality is a pattern property (form x register x immediate) - table shape-match never proves executability"
  ],
  "coordination": "AsmEncodingRE has the full sweep table and the harness recipe; the remaining item (naming gold's load-bearing runs) needs the CV3600xx table re-extract, not more probing - evidence and recommendation delivered."
}