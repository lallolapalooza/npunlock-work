{
  "status": "item 1 (CALLS) LANDED + hardware-verified; items 2-5 not started",
  "item1_calls": {
    "implemented": [
      "llvm/lib/Target/SHAVE/SHAVEISelLowering.cpp: LowerCall (direct calls only, 8 register args i18..i11, register-mask + glue, result in i18), LowerReturn/LowerFormalArguments re-pointed at the measured ABI (ret i18, 64-bit hi i18/lo i17), FNEG as sign-bit XOR (needed for silu's -x)",
      "SHAVEInstrInfo.td: SHAVEISD::CALL SDNode, SHAVECALL pseudo (isCall/isPseudo/Defs=r0..r10), BRU_SWP, LDILSYM/LDIHSYM (reloc 200/202), SUBI/ADDI, STO32I/LDO32I",
      "SHAVEISelDAGToDAG.cpp: SHAVEISD::CALL selection (chain/glue last, per InstrEmitter::countOperands)",
      "SHAVEInstrInfo.cpp: expandPostRAPseudo(SHAVECALL) -> IAU.SUB i19,i19,8 ; LSU1.STO.32 i30,i19,4 ; LDIL i30,sym ; LDIH i30,sym ; BRU.SWP i30 ; (6 delay fillers) ; LDO.32 i30,i19,4 ; IAU.ADD i19,i19,8",
      "SHAVERegisterInfo.cpp: i19 (SP) reserved; getCallPreservedMask = i18..i30 (0x7ffc0000)",
      "SHAVEFillDelaySlots.cpp: fill delay slots after EVERY delayed transfer (calls add a second one per block), LDILSYM/LDIHSYM/LDO32I/STO32I added to the LSU sets, and fixConstantToLSU now recognises the symbolic (LDILSYM,LDIHSYM) pair"
    ],
    "hardware_abi_measured": {
      "args": "i18, i17, i16, ... descending (i18 = arg0; measurements: copysignf read i18/i17 - probe returned -1.0 for copysignf(1.0f,-1.0f); fmaf(2,3,4)=10.0 proves arg2=i16)",
      "return": "i18 (expf(1.0f)=2.7182817f exactly; expf(-6.96148681640625)=0x3a786e2a = correctly-rounded)",
      "sp": "i19, live-in at kernel entry (measured 0x2e004328), grows down, [i19+8..] writable; link saved at [i19+4] (vendor pattern)",
      "link": "i30; call = BRU.SWP i30, return = BRU.JMP i30 (round-trip verified: the callee's i17=0xBBBB store was visible after return)",
      "callee_saved_measured": "i20,i22,i23,i25,i26,i27,i28,i29 all survive an fmaf call (differential magic-register probe); i0..i10 are scratch (expf clobbers i10)"
    },
    "new_hardware_rules_appended_to_FINDINGS": [
      "The callee-address LDIL/LDIH pair must sit >=6 issue slots before BRU.SWP. With the pair adjacent, BRU.SWP reads a stale i30 and NO CALL HAPPENS (the 'result' is just the unchanged argument register). Root cause of the 3rd bug fixed; the vendor's LDIH;LDIL;BRU.SWP only works because of the same forwarding.",
      "LDIL is immediate and ZERO-EXTENDS; LDIH inserts. Adjacent LSU1.LDIH then LSU0.LDIL loses the LDIL write (0x56781234 requested, 0x56780000 observed); LDIL-then-LDIH gives 0x56781234. Emission order in the backend is LDIL first.",
      "Assembler trap set re-confirmed: a single LDIL into i21 faults the kernel (immediates 0x2121 and 0x2020 both), i20/i22/i23/i25..i29 are fine."
    ],
    "acceptance_evidence": {
      "build": "ninja -C build -j6 clang: clean",
      "gate": "cd npunlock-work/npunlock && ./tools/npu_add1_smoke.sh --elf ../our-add1-fp16.elf -> exit 0, all stages passed, oracle exact (32/32), re-run after the final rebuild",
      "ctest": "ctest --test-dir npunlock/build/fresh -> 15/15",
      "l01_compile": "corpus/kernels/l01_silu_f32.c compiles/assembles/links (against vendor mlibm.a)/validates - corpus row PASS, text=976 B, 1 BRU.SWP",
      "l01_executes_on_npu": "dump_probe ACTUAL[0] = 0xbbd7f9d3 = silu(in[0]) bit-exact for the runtime input in[0] = -6.96148681640625 (host double oracle); ACTUAL[1] is 1 ULP from the oracle = expf's own rounding. Earlier probes: expf(1.0f)=e exact, expf(-6.96148681640625)=0x3a786e2a exact, expf(-0.0008802036754786968) 1 ULP.",
      "corpus": "run_corpus.sh --tag cw1final -> 20/33 PASS (recorded baseline results_kernels.tsv = 15/33). New passes vs that baseline: a03_gelu_fp16, a04_gelu_fp32, l01_silu_f32, l04_vec_dot_f32, l06_scale_f32. Zero regressions."
    }
  },
  "items_not_started": {
    "int_to_fp_fp_to_int_fsqrt": "not started; l02_rms_norm_f32 still ISEL-CannotSelect",
    "f32_value_select": "not started; l03_softmax_f32 still reports 'only i32 value-selects are supported'",
    "cheap_isel": "not started (mulhu/sdivrem/i64 mul/ctlz/cttz/ctpop/bswap/fabs/fpow)",
    "globals_brjt_frames_spills": "not started; b18_globals/b12 still CannotSelect. BRIND is still falsely declared Custom in the ctor, which makes areJTsAllowed() true -> jump tables get created; per GapGlobalsFrames-2 that claim should be dropped rather than implemented."
  },
  "open_issues": [
    "My 'expf result is correct' evidence is solid for the registers used (i18 out, i20..i29 preserved). Two probe observations were NOT fully root-caused and are reported as open: (a) in the fixed add1 carrier the kernel sees an output region of >=32 bytes, but probes that store 8 consecutive float words only ever show the first ~2 words landing until the writes are made volatile-ordered - i.e. the test carrier's store visibility has quirks that I did not finish characterising; (b) GapCalls-2's DWARF-derived preserved set 0xBFF7F800 (i11..i18 + i20..i29 + i31) was REJECTED because declaring i11..i17 preserved regressed l01 from producing silu values to writing nothing, and a (partly broken) fmaf probe planted in i11..i14 read back 0x33800000/0/0/0. A correct i11..i17 probe (reload the out pointer from [i19+8] AFTER the call) is the next measurement to run before ever widening the mask.",
    "Calls to functions defined in the same module are a clean loud error ('callee-saved registers are not saved by the prologue'), not silent wrong code; b08_calls_internal moved from ISEL-CannotSelect to that diagnostic. Enabling it needs prologue/epilogue callee-save work (item 5).",
    "Stack-passed arguments (>=9 args) are a clean loud error; nothing in the llama.cpp path needs them."
  ]
}