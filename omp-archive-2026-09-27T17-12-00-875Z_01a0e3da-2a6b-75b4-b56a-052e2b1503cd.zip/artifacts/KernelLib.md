{
  "status": "delivered (budget-stopped; two small follow-ups listed)",
  "deliverable": {
    "dir": "/home/asdf/projects/npunlock-work/kernel-lib",
    "files": [
      "build.sh (reproducible: toolchain -> elf/ -> validate -> manifest.json -> engine-ops.py; --npu adds hardware evidence; retries transient toolchain-relink failures, never real diagnostics)",
      "manifest.json (23 kernels x build status x NPU evidence x carrier contracts x measured toolchain rules x latency)",
      "engine-ops.py (the ENGINE_OPS tuple ggml-shave's build_kernels.py consumes)",
      "src/*.c (23 kernels) + src/<name>.opts (FIXUP/LDSCRIPT per kernel) + src/npunlock/npu3720_kernel.h + src/shave_kernel.ld + src/kernel_quad.ld",
      "elf/*.elf (23, sha256 in manifest)",
      "carriers/*.blob + .json (Abs 1x1024/1x16384 unary, Maximum 2-input 1x1024/1x16384, measured contracts)",
      "tools/{make_carrier,run_npu,make_manifest,patch_ranges,klib_probe.c,fixup_asm,elf_entries,validate_elf}.py",
      "reports/npu-evidence.json (raw INPUT/EXPECT/ACTUAL per case, 26 cases)"
    ]
  },
  "hardware_verified": {
    "byte_exact_on_npu": [
      "add_f16_packed (16 el/inv; byte-identical output to ggml-shave's pinned shave_add.elf)",
      "add_f16_packed at 512 and 8192 el/inv (Abs 1x1024 / 1x16384)",
      "copy_f16 (byte-transparent) at 8/16/512/8192 el/inv",
      "add_f16 (2 input records, Maximum carrier) at 256 and 4096 el/inv",
      "mul_f16 (2 records) at 256 and 4096 el/inv",
      "scale_f16 (2 records) at 256 and 4096 el/inv",
      "mul_f16_packed at 512 and 8192 el/inv",
      "silu_f16 bit-exact, 0 mismatched elements, at 8/512/8192 el/inv (mlibm expf)",
      "multi4 multi-entry image: range0=kb_mul_packed(+0x800), range2=copy(+0x000) byte-exact in ONE invocation at 16/512/8192 el/inv"
    ],
    "within_tolerance": [
      "gelu_f16 max_abs_error 4.9e-4 (16 el) / 2e-3 (512, 8192 el) vs a host numpy reference; fp16-arithmetic path + vendor tanhf last bit"
    ],
    "all_evidence": "26 cases, every one executes=True and repeat-consistent; add32_lib byte-identical to the backend's verified kernel"
  },
  "manifest_fields_per_kernel": [
    "op, ggml_ops[], dtype, abi_form, record_indices, constraints, links_mlibm",
    "source + source_sha256, elf + elf_sha256, text_bytes",
    "build{compile,assemble,link,validate,message} and status (EXECUTED_VERIFIED / EXECUTED_VERIFIED_TOLERANT / VALIDATED / COMPILE_FAIL)",
    "entry_symbol (controlled_act) via abi.entry, entry_offsets[] with aligned_0x400 for the multi-entry image",
    "execution[]{carrier, carrier_facts{elements_per_invocation, act_targets, act_groups, load_bearing_ranges}, plan{group: elf+sha256}, range_offsets/range_changes, executes, exact_match, mismatched_elements, max_abs_error, tolerance, mean_wall_seconds}"
  ],
  "integration_proofs": [
    "ggml-shave: ran their own tools/build_kernels.py with ENGINE_OPS from engine-ops.py + --kernels kernel-lib/src --prebuilt kernel-lib/elf: it pinned add_f16_packed.elf + copy_f16.elf, patched both ACT groups of abs-abs-1x32.blob, emitted shave-kernels.inc (573402 B, 2 engine ops)",
    "NPURuntime: sent the exact fields they asked for (elf+entry_symbol, group plan per kernel, links_mlibm)",
    "PosixWorker: requested shipped-path 2-input carriers (they delivered build/fresh/npu-carrier/two-input/maximum-1x1024/16384); my make_manifest picks them up as shipped:* when present"
  ],
  "key_measurements": {
    "large_tiles": "Abs(1,16384) carrier = 4 ACT targets, 8192 f16 per invocation; add/mul/silu/copy/gelu all executed at that size",
    "carrier_creation": "IR->blob on Linux via the driver graph compiler (tools/make_carrier.py, 0.3-0.9 s); Add/Multiply/Relu/Clamp/Subtract are DPU-only and NOT patchable, Abs/Exp/Tanh unary and Maximum/Minimum/Divide/Power 2-input are",
    "multi_op": "range code address is rounded down to 0x400; entries at 0/0x400/0x800/0xC00 in one image run in different ranges of one invocation (verified); source of the rule: multiop workstream, pattern re-implemented in tools/patch_ranges.py + src/kernel_quad.ld",
    "latency_basis": "0.80 ms graph execute+fence per invocation and ~1.0-1.2 ms per reused-session call (npu-runtime workstream); kernel-lib's probe (fresh process, graph created per call) measures 0.03-0.09 s and is recorded as such, NOT as kernel time"
  },
  "toolchain_findings_reported": [
    "D1 fp32 ADD/SUB of two runtime registers needs the '; fmt=2' register hint (tools/fixup_asm.py)",
    "D2 hardware-selector literals (1.0/0.5/2.0/...) must NOT be rewritten; kernels with them carry FIXUP=off",
    "D3 fp16-typed arithmetic is self-annotated by the compiler - all new fp16 kernels use __fp16 arithmetic (this is what unblocked mul/scale/gelu while the fp32 MUL defect was in flight)",
    "D4 mlibm expf/tanhf verified",
    "D5 a constant used after a call in fp16 code is emitted register-form without being materialised (gelu spelled hx + hx*t)"
  ],
  "remaining_gaps": [
    "rope_f16/rope_f32: COMPILE_FAIL (fpow / LLVM crash) - source present, status recorded",
    "rms_norm/softmax/vec_dot: now compile+validate with the fixed toolchain but have no execution evidence (need a carrier with a 1-element output record / reduction semantics)",
    "f32 kernels: compile+validate only (no f32 carrier built yet)",
    "open observation: re-pointing an ACT range at the multi-entry image's mlibm-calling entry (kb_silu +0xc00) hangs, while the same silu code patched alone is bit-exact on the same carriers; mlibm-free entries are the verified ones"
  ],
  "next_steps_suggested": [
    "porting rms_norm/softmax/vec_dot evidence: needs a 1-element-output carrier (Abs on a (1,1) or (ne00,1) IR) - tools/make_carrier.py already parametrises the shape",
    "f32 carrier (Abs with dtype f32) to activate the f32 kernels",
    "ask the compiler owner about the mlibm-call-in-redirected-range hang"
  ]
}