{
  "status": "complete",
  "deliverables": {
    "harness": "eval/run_compare.sh — usage() fixed (dynamic header block + full option list), --score-only added, absolute --out/TMPDIR bug fixed, llama-bench cwd bug fixed; eval/tools/npu_engine_cost.py added (engine-reported setup_ms/npu_ms/avg_invocation_us); dead npu_invocation_bench.py deleted; compare.py new cost schema + malformed-bench hardening; npu_cycle_time.py /dev/accel/accel0; README updated",
    "results_doc": "npunlock-work/eval/baseline/RESULTS.md (470 lines: provenance + hashes, 3-regime NPU cost table, per-prompt baselines, determinism, offload counters + node census, verdict, repro commands, CPU-bench appendix)",
    "run_dir": "npunlock-work/eval/baseline/2026-09-28-gemma4-e4b-q4_0/ — summary.md, summary.json, cpu/cpu2/npu records + verbatim llama-cli streams, bench_{cpu,cpu2,npu}.json, npu_engine_cost.json, npu_cycle_cost.json"
  },
  "commands": [
    "eval/run_compare.sh --modes cpu,cpu2 --out <abs>/eval/baseline/2026-09-28-gemma4-e4b-q4_0",
    "eval/run_compare.sh --modes npu --timeout 900 --out <same>",
    "eval/run_compare.sh --score-only --modes cpu,cpu2,npu --out <same>  -> exit 1 (two divergences: npu/explain, npu/longctx)",
    "llama-bench -m ../models/gemma-4-E4B-it-Q4_0.gguf -p 128 -n 32 -r 2 -t 8 --no-warmup -dev {none,SHAVE0} -o json (from cwd=llama.cpp; the harness's own bench step was broken, fixed after)",
    "GGML_SHAVE_STATS=1 ggml-shave-selftest / llama-cli --list-devices / tools/npu_engine_cost.py / tools/npu_cycle_time.py",
    "taskset -c <P-core> ./f16add_bench (throwaway gcc -O3 -mavx2 -mf16c build; source in the RESULTS.md appendix)"
  ],
  "recorded_numbers": {
    "cost_regimes": "F fresh graph per call 22.9-55.4 ms (multiop §3; old engine 460682db; npu_cycle_time probe 31 ms, full CLI cycle 243 ms -> 4.1 deployments/s); W live graph in-process 0.143-0.5 ms = 149 k -> 77.4 M elem/s at N=32..16384 (multiop mprobe); W' shipped warm engine 4.85-5.11 ms/invocation (this run; engine setup 5-22 ms once; selftest 7.6 ms); CPU P-core f16 vector 2.4-5.4e9 elem/s, scalar 1.6e8, f32 mul 2.6 µs at N=2560",
    "offload_stats": "npu: 71383 invocations, 71383 offloaded (100%), 195,395,072 elements, 364.9 s device time = 5.11 ms/invocation (0.54 M elem/s), unsupported 0, declined 65357/prompt (89567 longctx), per_op add 3427 + mul 5987 (longctx), copy 0; cpu/cpu2: 0 invocations, declined 2975 (4271 longctx)",
    "per_prompt_exactness": "npu vs cpu: 6/8 exact (arith, short, repeat, list3, count10, code); 2/8 diverged (explain first diff char 47, longctx char 111 — both inside the [Start thinking] preamble); cpu vs cpu2: 8/8 byte-identical",
    "speed_bench": {
      "cpu": "pp 28.391±0.305, tg 8.231±0.019",
      "cpu2": "pp 21.725±1.609, tg 6.546±0.194",
      "npu": "pp 18.889±1.183, tg 0.458±0.009"
    },
    "speed_cli_means": {
      "cpu": "18.16 pp / 6.55 tg t/s, 23.9 s mean wall",
      "cpu2": "13.65 / 5.40 t/s, 26.7 s",
      "npu": "8.10 / 0.463 t/s, 81.4 s"
    }
  },
  "verdict": "Offload does NOT pay at model scale with these numbers (capability milestone, not a throughput win). Per element the CPU is ~30-50x faster than the NPU's best warm case (live graph, 77.4 M elem/s), ~2e4x faster than the shipped warm engine, and ~1e5x faster than a fresh graph per call; end-to-end the offloaded run is 2.7-10x slower (generation 0.46 vs 6.55 t/s, mean wall 81.4 s vs 23.9 s). The nodes that are even eligible are the cheapest ones: of 282 census node signatures only 13 (small dense f32 ADD/MUL) are accepted, every MUL_MAT/ROPE/RMS_NORM/SOFT_MAX is declined for lack of a kernel. What could still pay: kernels with much higher arithmetic per element (8 hardware-verified now, silu_f16 exact at 8192 elements/invocation), NPU/CPU overlap, and batching provably-independent nodes to amortise the ~1 ms fence wait.",
  "blockers_and_incidents": [
    "build/bin changed mid-first-run (libggml-shave.so rebuilt at 16:10:23 while my run was in flight) -> that run was discarded and re-run on the frozen b0671c3c build, whose sha256 I verified identical before and after the 25-min NPU pass",
    "I edited eval/run_compare.sh while a background run was executing it -> bash read garbage at the bench step (syntax error, benches+summary lost). Recovered: prompt records survived, benches re-run by hand; documented in RESULTS.md §6",
    "harness bug 1 (fixed): relative --out was exported as TMPDIR, so the engine's mkdir ran with cwd=llama.cpp, failed, and -dev SHAVE0 silently offloaded nothing (engine:\"unavailable\")",
    "harness bug 2 (fixed): llama-bench invoked without cwd=$LLAMA_DIR -> relative --model never loaded, all bench_*.json empty",
    "/tmp (tmpfs) hit a quota mid-session (EDQUOT); all artifacts live under npunlock-work/eval/** and the harness scratch is inside the run dir, so nothing of mine depended on it",
    "longctx cannot pass its content check in ANY mode at the frozen n_predict=24 (gemma-4 spends the budget inside [Start thinking] and never reaches MAGENTA-7741); documented as a property of the frozen set, visible identically on the CPU baseline, not a backend effect",
    "open attribution: the npu divergences on explain+longctx are single-flipped-token shaped and consistent with the backend's documented fp32 denormal flush-to-zero, but I did not isolate the offending tensor/value (follow-up suggested to GGMLBackend-4: per-node value dump on explain at n~8)",
    "GGMLBackend-4 landed a newer lib (9dc31b0e, 16:36, +silu/tile_histogram, claims ~1.6 ms/inv) after my pass; RESULTS.md stays pinned to b0671c3c with the hash recorded, and a re-run on the new lib is available on request"
  ],
  "peer_notes": "Answered GGMLBackend-4's question: llama-cli -dev SHAVE0 exits cleanly through the harness — 8/8 npu records exit_code=0, no timeouts — because cli_run.py gives it stdin=b'' (EOF) plus -st; their shell hang is most likely the chat REPL waiting on stdin, reproducible/fixable with `< /dev/null`."
}