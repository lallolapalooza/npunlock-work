{
  "final_deliverable_state": {
    "gates": "shave-isa/gates.py = 188/188 ALL GATES GREEN (G10 added for the fmt-hint diagnostic); gold disasm->asm roundtrip 192/192 byte-identical with the unchanged gate command; obj==asm byte equality on 262 compiler lines; 84/84 + 104/104 peer streams assemble/reproduce.",
    "hashes": {
      "PACKETS.md": "3c6852bd5ced0a509988774a215354ce4fb8d1de57e1827ad99e8fc47b266b5f",
      "VALIDATION.md": "f7063ab0700e602df775a62f5c8fb8914be4d5ca09e0c089b3709a9f2ec79c0c",
      "cal_fix.py": "d330cf2e5e8c6974bd1ed8efaba01fa4d04cec6d5518456136d217c981acc51b",
      "encodings.json": "5660b39341820ee9b15bc6b52ed4b0572c1d95b5a3edf4df8a1dbd852c9fe55a",
      "gates.py": "3482d8f2f253013518c43f7b3ae109c99f7c2f4c76dbee9777e976b1be6f840f",
      "shave_asm.py": "bccaac0cd287745e00ec2c45b728abf90b5b1f1e7ed67a992be50e7cc6612a1b"
    },
    "kernel_acceptance": "`cd npunlock && ./tools/npu_add1_smoke.sh --elf our-add1-fp16.elf` -> exit 0, oracle exact (ACTUAL == EXPECT, 32/32), confirmed across 12/12 non-colliding runs by two independent agents including a byte-identical rebuild after this assembler revision.",
    "rules_automatic": [
      "D1 6 delay-slot fillers after unconditional branches (compressed one-byte 0x50 default; idempotent vs all filler encodings)",
      "D1b conditional-branch descriptor backstop (1b 50 fwd / 2b 50 bwd) only when the source has none; `; desc=<hex>` verbatim vendor variants",
      "D2 dataflow-aware 6-slot load->consumer",
      "D2b SAU.DIV* >= 13 slots; D2c LDIL/LDIH pair -> LSU spacing; D2d SAU.ADD.F32 >= 2 slots",
      "D3 LSU0 loads / LSU1 stores with silicon-verified structural rewrite and `; fmt=` pin",
      "D3b load write-back isolation (same-unit 1..5 slots for plain loads, any-unit 1..7 for LD.32.F16.F32)",
      "D4 aliased store->load distance 1",
      "D5 offset-0 LDO -> verified LD.32 for destinations <= i15",
      "D6 + diagnostics: high LSU register pattern warnings, dead 2-op LD.8, dropped fmt hints, missing descriptor, LDI-pair spacing, same-unit LSU pairs - all five are listed in PACKETS.md and never change bytes",
      "obj writer == asm writer (AU-immediate bit-31 fix) and verbatim mode for disasm listings / --exact"
    ],
    "still_owned_by_peers": [
      "Conditional-branch descriptor emission and flag protocol (backend).",
      "LDIL/LDIH-pair padding (backend; assembler warns, --ldi-pair-pad available).",
      "Register/immediate selection rules (r0..r15 LSU operands, effect-verified immediates).",
      "LD.8-class silicon verdict (AsmEncodingRE + StrangeSole, shapes A-F pending; I hold the warning scope and will add a rewrite or widen the warning when it lands)."
    ]
  },
  "status": "complete"
}