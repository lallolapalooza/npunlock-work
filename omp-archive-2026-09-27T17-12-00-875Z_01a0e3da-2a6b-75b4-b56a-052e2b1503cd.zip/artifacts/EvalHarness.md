{
  "progress": {
    "status": "in-flight",
    "done": [
      "eval/ dir created; prompts.json frozen (8 prompt kinds)",
      "tools/cli_run.py, compare.py, dump_prompts.py, gen_prompts.py, npu_invocation_bench.py, npu_cycle_time.py written + syntax-clean",
      "compare.py validated with positive/negative controls (exact vs DIVERGED, exit 1)",
      "eval/README.md written",
      "NPU invocation cost measured: ~22 ms -> ~45 invocations/s (persistent engine); control no-NPU 13-17 us; patch+probe cycle ~250 ms -> ~4 deployments/s (multiop/REPORT.md absent, measured directly)",
      "llama.cpp SIGFPE with -dev SHAVE0 reproduced, isolated to common/fit.cpp, reported to GGMLBackend-2; -fit off workaround applied to both modes"
    ],
    "pending": [
      "full CPU+NPU baseline run finishing (cpu 8/8 records done, npu 6/8)",
      "determinism pass (cpu vs cpu2)",
      "usage() cosmetic fix in run_compare.sh (deferred: bash reads a running script lazily)",
      "eval/baseline/RESULTS.md with recorded numbers"
    ]
  }
}