{
  "summary": "shave-isa extended with moviAsm-contract `obj` mode (ELF32 LE ET_REL EM_SPARC objects that the patched lld links end-to-end), gold roundtrip proven byte-exact through link, gate1.o delivered and parser-verified, decode coverage raised 22.4%→78.1% (gold) / 20.3%→71.8% (ef_sqrt) with exact 192/192 roundtrip, all blockers documented precisely.",
  "obj_mode": {
    "cli": "shave_asm.py obj [file] [-o out] [--cv <cpu>] [--noSPrefixing]; stdin default, stdout default",
    "contract_check": "npunlock/src/shavecc/shavecc.c:310 assemble_args = {moviAsm.dll, --cv, 3720xx, --noSPrefixing}; POSIX replaces argv[0] with bin/moviAsm (line 471); .s on stdin, ELF on stdout (link stage is the only stdin-less one). Both flags accepted after `obj` and ignored — verified: `cat gate1.s | obj --cv 3720xx --noSPrefixing` byte-identical to `-o` build.",
    "conventions": "ELF32 LE ET_REL EM_SPARC(2), no phdrs; .text.<fn> PROGBITS AX align 16; symtab = NULL + SECTION + GLOBAL FUNC (+locals forced by .type/.size/.local/reloc); .L/LBB/Lfunc labels never emitted; .rela.<sec> SHT_RELA entsize 12 link=symtab info=target, r_info=(sym<<8)|type; relocs: LDIL→200/LDIH→202 (field zeroed, r_offset=imm byte offset = vendor pair geometry), branch→209 pre-encoded r_offset-instr_start (=1 for b5/c7 forms, matches ef rela old), .word sym→208; intra-section branches resolve at assemble time when displacement fits signed field (same final bytes as vendor relocate).",
    "file_sym_decision": ".file parsed but NOT emitted: upstream lld-14 default discard KEEPS STT_FILE (verified live) while gold linked symtab is NULL+controlled_act only — vendor entry.o had none; emitting one would break byte-parity (LAYOUT_SPEC §5 drop-claim wrong for lld-14; SECTION syms verified dropped). Documented in VALIDATION.md + ENCODING_NOTES §10."
  },
  "gate_A_gold_roundtrip": {
    "object_text": "byte-identical to gold .text 192/192",
    "link": "llvm-14/build/bin/ld.lld contract argv + shave_kernel.ld exit 0",
    "byte_compare": "linked .text vs gold [0xc0,0x180): MATCH (exact acceptance)",
    "layout": "file size 820 = LAYOUT_SPEC §6 banner model exactly; .arg.data@0xb4, .text@0xc0, .comment@0x180 size 0x36, .symtab@0x1b8, .shstrtab@0x1d8, .strtab@0x20c, e_shoff=0x21c all as predicted; only e_shoff (char 33) differs from gold inside [0,0x180)",
    "symtab": "linked = NULL + controlled_act (0x1d000000, size 187) — identical to gold",
    "parser": "npunlock_parse_shave_elf status=0 ok, file_offset=192 size=192 addr=0x1d000000 entry=0x1d000000"
  },
  "gate_B_gate1": {
    "object": "shave-isa/out/gate1.o (1744 B, sha256 2beb1883…, from /tmp/gate1.s; zero relocations — all branches inline)",
    "readelf": "clean; .text.controlled_act PROGBITS AX align 16 size 1378; symtab NULL + SECTION + controlled_act FUNC GLOBAL size 1378",
    "link": "ld.lld contract argv exit 0 → .text@0x1d000000 size 0x570, symtab NULL + controlled_act",
    "parser": "npunlock_parse_shave_elf status=0 ok, file_offset=192 size=1392 entry=0x1d000000"
  },
  "decode_work": {
    "gold": "150/192 = 78.1% decoded as instructions (baseline 22.4%); disasm→asm byte-identical 192/192",
    "ef_sqrt": "1539/2144 = 71.8% (baseline 20.3%)",
    "root_cause_found": "gen_encodings packed records first-at-bottom while validated vendor model is first-at-top; extraction list order varies per builder (provenance in defs_extracted.pkl func field). patch_encodings.py: +5,459 first-at-top repacked forms (LDO.64/BRU/LDI families now decode), repaired BRU.BRA fmt=102 to [b5][rel16][pred8], dropped 2 corpus-absent encode-poison forms (LDIL 5-byte, BRU rel14: 0 hits/7394B), normalized BRU 0X→rel, stamps corpus_hits + encode_priority (resolve_form now orders: explicit priority → corpus presence → specificity)",
    "blockers_precisely_documented": [
      "LDI hi-half overlay: corpus-derived LSU1.LDIH fmt100 (fixed=0x3a9) operational (102 corpus hits, reloc-anchored); exhaustive search: NO schema-16 def has D=937 — not derivable from this DLL revision",
      "b5-branch: SOLVED — layout [0xb5@byte0][rel16@1-2][pred8@byte3] (gold×4 + ef×8 rela sites; pred byte carries gate1's BRU.BRA i16 → 0x10); NO schema-16 def has D=181 — corpus-derived",
      "prologue a9-53-ff-7f: first pair now decodes (LDIH i10,0x7fff + LDIL i10,0xffff); remainder partial (25/32 B)",
      "X don't-cares: closed via raw= (roundtrip exact)",
      "remaining 42 gold bytes/19 runs: 3 attempts all negative — full repack of 7,099 lists (0 hits in these runs), both packings of all 32 ok=False defs (0 matches at any offset), names outside canonical set (0) — byte patterns absent from this DLL's tables; .byte fallback keeps roundtrip faithful",
      "LDO.32-vs-LDO.64 mnemonic label for the c2…5-byte family left open (byte layout identical; documented)"
    ],
    "structure_proof": "all 5 gold BRU.BRA targets (0xb7 epilogue ×3, 0x4a loop head, 0x98 loop body) land on decoded instruction starts"
  },
  "coordination": "ToolchainBuild wired bin/moviAsm to `obj --cv 3720xx --noSPrefixing`; their wave-2 E2E manual gate PASSES npunlock parser through moviCompile→moviAsm(mine)→moviLLD (their report: 1744 B object, .text 1378 — matches my out/gate1.o); their gated shave_add1 ctest RED only on expected gold byte-compare classes (clang ISel + banner delta), no structure bug.",
  "docs": "VALIDATION.md rewritten (status table, verbatim gate pastes, obj conventions, precise blocker attempts); ENCODING_NOTES.md §7 rewritten to current status + new §10 (record-order discovery, patch_encodings behavior, encode evidence ordering, STT_FILE finding); shave_asm.py module docstring documents obj CLI + contract flags.",
  "files": {
    "owned_dir_changes": [
      "shave_asm.py (obj mode, rel-operand target fix, resolve_form evidence ordering, Insn corpus_hits/encode_priority, docstring)",
      "encodings.json (via patch_encodings.py: +5,459 repacked forms, BRU repairs, 2 drops, hits/priorities; backup /tmp/encodings.json.bak)",
      "patch_encodings.py (new, documented build step)",
      "VALIDATION.md, ENCODING_NOTES.md",
      "out/gate1.o (deliverable, kept)"
    ],
    "verification": "final consolidated run: disasm/asm/obj all green; contract argv byte-identical; gate1 link+parser ok; gold obj link byte-compare MATCH + parser ok; py_compile clean"
  }
}