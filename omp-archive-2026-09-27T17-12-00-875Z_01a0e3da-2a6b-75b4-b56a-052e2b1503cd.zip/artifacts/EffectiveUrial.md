{
  "status": "complete",
  "files_changed": [
    "README.md — 'Get the SHAVE toolchain' status corrected (built: clang SHAVE backend + recovered assembler + patched lld); newer-NPU bullet 2 rewritten to native-backend retargeting route; License split (toolchain reimplementation Apache-2.0 like repo; mlibm.a + original MoviTools/Intel/Movidius binaries external proprietary, not covered/redistributed); 'remain untested' routes claim corrected to 'need broader validation'; no Linux-needs-DLLs/wine claim existed or remains",
    "wiki/GET_SHAVE_TOOLCHAIN.md — status updated from 'under construction' to built-and-packaged (workspace shave-toolchain-root/, structure-valid E2E); build section rewritten from shave-toolchain-root/README.md (wrapper contract argv, entry.c→'-' rewrite, shave_asm.py obj, lld -o - mktemp staging) with no invented commands; E2E_REPORT/shave_add1 status; licensing paragraph points at README license boundary",
    "wiki/PORTING.md — 'Superseded: MoviTools invocation on Linux' updated (binaries landed; shave_add1 gated on ISel convergence, not harness); Linux kernel-build bullet updated; Route 1 target wording de-vendored; Route 2 rewritten from 'find generation-matched MoviTools' to 'retarget the native SHAVE toolchain', vendor-package extraction kept as provenance-only",
    "wiki/REVERSE_ENGINEERING.md — section 4 now points at shipped outcome (r2gvp04w-re + shave-toolchain-root + workspace E2E_REPORT.md); history retained",
    "wiki/DEVELOPMENT.md — documents native_shave_stage fixture coverage (fake toolchain argv/pipes/deadlines/-T temp staging), corrects shave_add1 gating wording (byte-compare vs gold, red pending ISel convergence), new 'Linux hardware smoke' section for tools/npu_add1_smoke.sh + NPU_REPORT.md",
    "wiki/CUSTOM_KERNELS.md — embedded header reworded off 'npunlock.dll' to 'the native library'",
    "ABI/MOVITOOLS.md — top status now 'contract satisfied by built toolchain root'; -T temp-file staging paragraph verified against final native contract",
    "ABI/KERNEL_ELF.md — build pipeline annotated: DLL names = historical Windows flow; native path uses same flags via toolchain root with TMPDIR staging for -T script/object and lib/mlibm.a",
    "ABI/MLIBM_SYMBOLS.md — 'MoviTools must accept the call' → toolchain-neutral; title/inventory kept",
    "tests/fixtures/README.md — gold provenance kept (vendor MoviTools) + honest status: structure reproduced E2E, byte-exactness tracked in workspace E2E_REPORT.md via gated shave_add1",
    "BUILD_REPORT.md — appended 'Docs sweep' section (files changed + verification)"
  ],
  "swept_clean": [
    "wiki/HOW_NPUNLOCK_WORKS.md, MODEL_TO_MACHINE_CODE.md, PYTHON_API.md, LIMITATIONS.md, PORTING_PROBE_BUNDLE.md, docs/C_API.md — no now-false DLL/wine/MoviTools-required statements found; vendor-history sections retained"
  ],
  "grep": "movi_dll|MOVITOOLS_DIR|movitools|MOVITOOLS|movi-dll|GET_MOVITOOLS clean outside BUILD_REPORT's historical rename table; all remaining 'wine' mentions are negations ('no wine')",
  "verification": {
    "build": "cmake --build build/fresh -j8 — 100% built, no relink errors",
    "ctest": "ctest --test-dir build/fresh → 100% tests passed, 0 tests failed out of 15 (one transient native_shave_stage failure on a mid-sweep rerun, passed on immediate rerun and final full run; docs-only edits since)",
    "python": "PYTHONPATH=python python3 -c 'import npunlock' → import ok (python_api ctest also green)"
  },
  "not_touched": [
    "llvm-14/",
    "shave-isa/",
    "lld-sparc/",
    "shave-toolchain-root/",
    "E2E_REPORT.md",
    "NPU_REPORT.md",
    "src/shavecc code",
    "test logic"
  ]
}