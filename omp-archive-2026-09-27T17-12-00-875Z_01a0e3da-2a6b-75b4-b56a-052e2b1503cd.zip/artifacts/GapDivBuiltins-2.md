{
  "task": "GapDivBuiltins-2 — READ-ONLY plan: (a) int div/mod & wide multiply, (b) bit builtins, in llvm-14/llvm/lib/Target/SHAVE",
  "status": "complete (no repo files modified)",
  "part_a_wide_multiply_and_divmod": {
    "root_cause": {
      "mulhu": "ISD::MULHU has no setOperationAction and no .td pattern -> default Legal -> `Cannot select: mulhu`. Created by DAGCombiner::BuildUDIV/BuildSDIV (TargetLowering.cpp:5494 GetMULHU only needs Legal-or-Custom) for x/const, and by InstCombine for r19's (a*b)>>32.",
      "divrem": "ctor sets SDIV/SREM/UREM i32 = Expand; LegalizeDAG.cpp:3267 ExpandNode(SDIV) sees SDIVREM as default-Legal and CREATES an sdivrem node that nothing can select. UREM takes the same route via TargetLowering::expandREM -> udivrem (verified by compiling a urem-only kernel with the pinned toolchain).",
      "i64_mul": "MUL i64 = Expand -> ExpandIntRes_MUL -> TLI.expandMUL(OnlyLegalOrCustom) false -> __multi3 libcall (blocked by LowerCall)."
    },
    "changes": [
      "ctor: setOperationAction(ISD::SDIVREM, i32, Custom); setOperationAction(ISD::UDIVREM, i32, Custom);",
      "ctor: setOperationAction(ISD::SDIV, i32, Legal)  // was Expand — load-bearing, see below",
      "ctor: setOperationAction(ISD::MULHU, i32, Legal); setOperationAction(ISD::MULHS, i32, Custom)",
      "UDIV i32 stays Legal (existing SAU.DIV.U32 Pat); SREM/UREM stay Expand (route through expandREM -> Custom DIVREM)",
      ".td: def LMULL/LMULH (IAU.LMULL/LMULH), def SDIV (SAU.DIV.I32); Pat<(i32 (mulhu a,b)),(LMULH a,b)>; Pat<(i32 (sdiv a,b)),(SDIV a,b)>",
      ".cpp: LowerDivRem (ARM template) + LowerOperation cases for SDIVREM/UDIVREM (and MULHU/MULHS if Custom)"
    ],
    "code_sketch": "SDValue SHAVETargetLowering::LowerDivRem(SDValue Op, SelectionDAG &DAG) const {\n  bool Signed = Op.getOpcode() == ISD::SDIVREM;\n  EVT VT = Op.getValueType(); SDLoc DL(Op);\n  SDValue A = Op.getOperand(0), B = Op.getOperand(1);\n  SDValue Div = DAG.getNode(Signed ? ISD::SDIV : ISD::UDIV, DL, VT, A, B);\n  SDValue Mul = DAG.getNode(ISD::MUL, DL, VT, Div, B);\n  SDValue Rem = DAG.getNode(ISD::SUB, DL, VT, A, Mul);\n  SDValue Vals[2] = {Div, Rem};\n  return DAG.getNode(ISD::MERGE_VALUES, DL, DAG.getVTList(VT, VT), Vals);\n}\n// Multi-result Custom from LowerOperation is supported (LegalizeDAG.cpp:1277).",
    "why_no_loop": "SDIV must be Legal, not Expand/Custom: useDivRem (DAGCombiner.cpp:4089) bails when the DIV opcode is legal-or-custom, DAGLegalize routes SREM/UREM through expandREM (which sees the Custom DIVREM), and LowerDivRem then re-creates SDIV/UDIV which select as single machine ops. Any other action for SDIV makes LowerDivRem's own SDIV recreate a DIVREM node -> infinite legalization loop.",
    "constant_divisors": "No special work: DAGCombiner BuildUDIV/BuildSDIV emit the magic mulhi+shift sequence as soon as MULHU/MULHS are legal-or-custom (3-4 short ALU ops) instead of the 13-slot SAU.DIV. If MULHS is omitted, signed /const still compiles via SAU.DIV.I32 with a materialised constant. Pow2 divisors already fold to shifts.",
    "i64_consequence": "Declaring MULHU/MULHS i32 legal-or-custom makes TLI.expandMUL_LOHI succeed (TargetLowering.cpp:6402/6501-6512): i64 MUL inlines as 4x IAU.MUL + LMULH + ADD carries. No UMUL_LOHI needed. i64 SDIV/UDIV/SREM/UREM stay Expand -> libcalls -> b11 still FAILs (needs LowerCall).",
    "fallbacks": "If LMULH is not trusted: (i) MULHU Custom via the 16x16 partial-product decomposition (only IAU.MUL/AND/SHL/SHR/ADD), or (ii) MULHU/MULHS = Expand, which makes BuildUDIV return null so constant divisors fall through to SAU.DIV.U32 with an LDI32 constant."
  },
  "part_b_bit_builtins": {
    "changes": [
      "setOperationAction Custom i32 for CTLZ, CTLZ_ZERO_UNDEF, CTTZ, CTTZ_ZERO_UNDEF, CTPOP, BSWAP",
      "Pat<(f32 (fabs x)),(SAU.ABS.F32 x)>; Pat<(f16 (fabs x)),(SAU.ABS.F16 x)>; Pat<(i32 (abs x)),(IAU.ABS x)>"
    ],
    "mapping": {
      "ctlz": "31 - BSR(x), with (x==0) ? 32 : ... via SHAVEISD::SELECT (BSD gives the MSB index); ctlz_zero_undef = 31 - BSR(x)",
      "cttz": "(x==0) ? 32 : BSF(x); cttz_zero_undef = BSF(x)",
      "ctpop": "IAU.ONES(x) (equivalent fallback 32 - ZEROS)",
      "bswap32": "CMU.RVRS.32.8 (0 vendor hits -> probe) or the four shift/mask terms",
      "fabs": "SAU.ABS.F32 (SILICON-CONFIRMED) / SAU.ABS.F16, no fixup",
      "bonus": "ISD::ABS i32 -> IAU.ABS (r44 uses __builtin_abs); ISD::BITREVERSE -> IAU.RVRS"
    },
    "guaranteed_fallbacks": "ctlz/cttz binary-search shift+compare; SWAR popcount (0x55555555/0x33333333/0x0f0f0f0f); bswap shift/mask; fabs as IAU.AND 0x7fffffff — all using instructions the corpus already validates."
  },
  "encodings_reference_bytes": [
    [
      "IAU.LMULH i1,i2,i3",
      "86 45 84 01",
      "4B, table-derived; 303 vendor-ELF hits",
      "encoding med-high / semantics unprobed"
    ],
    [
      "IAU.LMULL i1,i2,i3",
      "86 44 84 01",
      "4B, 3126+80 hits",
      "med-high"
    ],
    [
      "IAU.MUL i1,i2,i3",
      "c6 42 84 01",
      "4B, 98+3 hits, already emitted",
      "med-high"
    ],
    [
      "IAU.MULSI",
      "c6 47 84 01",
      "4B, 934+116",
      "med-high"
    ],
    [
      "IAU.MULSU",
      "c6 46 84 01",
      "4B, 524+14",
      "med-high"
    ],
    [
      "SAU.DIV.I32 i1,i2,i3",
      "3c 46 84 81",
      "4B, 0 hits, sibling UDIV gold-proven",
      "med"
    ],
    [
      "SAU.DIV.U32",
      "3c 46 84 01",
      "existing gold-proven",
      "high"
    ],
    [
      "IAU.BSF i1,i2",
      "46 49 04",
      "3B, SILICON-CONFIRMED (cv_prototypes line 31)",
      "high enc / direction unprobed"
    ],
    [
      "IAU.BSR i1,i2",
      "46 48 04",
      "3B, 136+4",
      "med-high"
    ],
    [
      "IAU.BSFINV",
      "46 49 84",
      "3B, 25+4",
      "med"
    ],
    [
      "IAU.BSRINV",
      "46 48 84",
      "3B, 363+6",
      "med-high"
    ],
    [
      "IAU.ONES i1,i2",
      "46 43 04",
      "3B, 38+2",
      "med"
    ],
    [
      "IAU.ZEROS i1,i2",
      "46 43 84",
      "3B, 14",
      "med"
    ],
    [
      "IAU.ONES64 i1,i2,i3",
      "86 49 84 01",
      "4B, 14",
      "low-med (pair popcount)"
    ],
    [
      "IAU.ABS i1,i2",
      "46 44 04",
      "3B, 55+8",
      "med-high"
    ],
    [
      "SAU.ABS.F32 i1,i2",
      "2c 52 04 02",
      "4B, SILICON-CONFIRMED (cv_prototypes line 25)",
      "high"
    ],
    [
      "SAU.ABS.F16",
      "2c 52 84 02",
      "4B, 0 hits",
      "med"
    ],
    [
      "IAU.RVRS i1,i2",
      "46 52 04",
      "3B, 73+9 (bit reverse)",
      "med-high"
    ],
    [
      "CMU.RVRS.32.8 i1,i2",
      "81 5f 04 90",
      "4B, 0 vendor hits",
      "low"
    ],
    [
      "SAU.ILMULH.U32 i1,i2,i3",
      "3c 4b 84 01",
      "4B, 77 mlibm hits",
      "med"
    ],
    [
      "SAU.ILMULH.I32 i1,i2,i3",
      "3c 4b 84 81",
      "4B, 2 hits (I32 = the missing MULHS single op)",
      "med"
    ]
  ],
  "test_matrix": [
    [
      "b01_int_arith",
      "FAIL mulhu",
      "OK"
    ],
    [
      "b02_div_mod",
      "FAIL sdivrem",
      "OK"
    ],
    [
      "b11_int64",
      "FAIL calls",
      "PARTIAL: mul OK, / and % still libcall -> FAIL"
    ],
    [
      "b25_large_const",
      "OK",
      "OK (regression guard)"
    ],
    [
      "r01",
      "FAIL mulhu",
      "OK"
    ],
    [
      "r03",
      "FAIL mulhu",
      "OK"
    ],
    [
      "r04",
      "FAIL sdivrem",
      "OK"
    ],
    [
      "r05",
      "FAIL sdivrem",
      "OK"
    ],
    [
      "r19",
      "FAIL mulhu",
      "OK"
    ],
    [
      "r44",
      "FAIL ctlz",
      "OK"
    ],
    [
      "r49",
      "FAIL ctlz",
      "OK"
    ],
    [
      "r50",
      "FAIL cttz",
      "OK"
    ],
    [
      "r51",
      "FAIL ctpop",
      "OK"
    ],
    [
      "r52",
      "FAIL bswap",
      "OK"
    ],
    [
      "r53",
      "FAIL fabs",
      "OK"
    ],
    [
      "a01_add1_fp16 gate",
      "GREEN",
      "must stay GREEN (fp-only path untouched)"
    ]
  ],
  "hardware_constraints": [
    "Load latency 6 slots, SAU.DIV* 13 slots, SAU.ADD.F32 >=2 slots (all measured). shave_asm._is_div already matches 'SAU.DIV.I32', so the new SDIV inherits the 13-slot padding automatically.",
    "No LSU op inside a load's visibility window (1..5 same-unit, 1..7 after LD.32.F16.F32); the new IAU/SAU/CMU ops are non-LSU so they are legal fillers and count in the backend's gap accounting.",
    "UNKNOWN LATENCY: shave_asm._producer_latency returns 0 for every new producer (LMULH/LMULL/MUL/BSF/BSR/ONES/ZEROS/ABS/RVRS/ABS.F32/ILMULH). Must be measured with the C1 k-sweep method, then added to _producer_latency (shave-isa owner) and SHAVEFillDelaySlots (backend) if >1.",
    "4-byte-shape destination hazard (ANNOTATED_RULES C19): dst sits in word bits 18..22 (byte2 bits 2..6). For some 4-byte AU/LD shapes silicon may honour only 4 bits, aliasing i16..i31 onto i0..i15. Every new 4-byte op has this shape; the existing 4-byte UDIV was only proven with low dsts. Probe LMULH/DIV.I32/ABS.F32 into i16/i20/i31 before shipping; mitigation = r0..r15 destination register class.",
    "Div/rem by zero and INT_MIN/-1 are C UB — SAU.DIV.I32 need not be guarded.",
    "CTLZ/CTTZ fixup uses SETCC+SELECT (branch diamond); the existing descriptor/filler machinery already handles it."
  ],
  "verification": [
    "Rebuild clang only, then the acceptance gate (npu_add1_smoke.sh -> exit 0, oracle exact) and ctest 15/15.",
    "run_corpus.sh --only <kernels> --tag <private> on kernels/ and --dir repros/ expecting the matrix above.",
    "Semantics probes with tmpdump/dump_probe --bundle (2-3 runs each, subtract carrier-init): BSF/BSR/ONES/ZEROS/ABS/RVRS at known inputs; LMULL/LMULH with 0xFFFFFFFF x 3 expecting low 0xFFFFFFFD, high 0x2.",
    "High-destination probe for the C19 alias question.",
    "Latency k-sweep per new producer; filler experiments only with tmpdump/runp3raw.sh."
  ],
  "gaps": [
    "i64 div/rem (b11) needs LowerCall or a software 64-bit divider — out of scope here.",
    "MULHS has no single ISA op: synthesise mulhu - ((a>>31)&b) - ((b>>31)&a), or use SAU.ILMULH.I32 (unprobed).",
    "All new-producer latencies unmeasured; shave_isa is read-only for this ticket.",
    "C19 4-byte destination aliasing is unverified and is the biggest correctness risk.",
    "Calls, globals, frames/spills, fp compares remain the project's larger blockers."
  ],
  "files_to_touch": {
    "llvm-14/llvm/lib/Target/SHAVE/SHAVEInstrInfo.td": "new defs + Pat",
    "llvm-14/llvm/lib/Target/SHAVE/SHAVEISelLowering.cpp": "ctor setOperationAction + LowerOperation cases + LowerDivRem/LowerMulHi",
    "llvm-14/llvm/lib/Target/SHAVE/SHAVEISelLowering.h": "private decls",
    "llvm-14/llvm/lib/Target/SHAVE/SHAVEISelDAGToDAG.cpp": "only if pseudos instead of plain Pat",
    "llvm-14/llvm/lib/Target/SHAVE/SHAVEFillDelaySlots.cpp": "only if a measured latency >1",
    "shave-isa/shave_asm.py _producer_latency": "read-only here — report as encoder/assembler issue"
  }
}