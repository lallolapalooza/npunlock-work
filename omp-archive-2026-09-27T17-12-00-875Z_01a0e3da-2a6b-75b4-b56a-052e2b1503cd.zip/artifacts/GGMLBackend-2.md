{
  "build_and_run": [
    "cmake -B build -DGGML_SHAVE=ON && ninja -C build -j6 ggml-shave-selftest ggml-shave-runner llama-cli",
    "./build/bin/ggml-shave-selftest                 -> exit 0, PASS (NPU offloads: 2)",
    "GGML_SHAVE_STATS=1 ./build/bin/ggml-shave-selftest -> ggml-shave-stats {\"engine\":\"ready\",\"invocations\":2,\"offloaded\":2,\"declined\":4,\"unsupported\":0,\"lanes\":16,\"tile_elements\":32,\"avg_invocation_us\":19401.9}",
    "./build/bin/llama-cli -m ../models/gemma-4-E4B-it-Q4_0.gguf -p \"What is the capital of France?\" -n 32 -c 2048 -t 8 --no-warmup -v",
    "off-path: cmake -B /tmp/build-off -DGGML_SHAVE=OFF ... && ninja -C /tmp/build-off ggml"
  ],
  "closing_note": "Stopped per the wrap-up order. Everything shipped is verified (selftest PASS) and the tree contains only verified artifacts (the unverified wide kernel source was removed and the README records the wide path as 'exists but not yet verified for a binary op'). The two follow-ups with the clearest payoff are: (a) finish the wide ADD wiring (one ENGINE_OPS row + per-tile packing + a selftest row) once the tile↔element mapping is confirmed, and (b) swap shave-engine.cpp onto NPURuntime's held session, which is what turns the ~19-46 ms/call into the ~5 M elements/s regime.",
  "files_added": [
    "llama.cpp/ggml/src/ggml-shave/CMakeLists.txt",
    "llama.cpp/ggml/src/ggml-shave/ggml-shave.cpp (device, host-backed buffer type, supports_op capability table, graph_compute, stats)",
    "llama.cpp/ggml/src/ggml-shave/shave-engine.h + shave-engine.cpp (runner lifecycle, tile transport, per-invocation latency)",
    "llama.cpp/ggml/src/ggml-shave/shave-runner-protocol.h + shave-runner.c (NPU child process, compiles npunlock src/linux_probe/infer_engine.c in)",
    "llama.cpp/ggml/src/ggml-shave/kernels/{shave_act.h,shave_add.c,shave_copy.c} + kernels/prebuilt/{shave_add.elf,shave_copy.elf}",
    "llama.cpp/ggml/src/ggml-shave/tools/build_kernels.py (compile -> fmt fixup -> assemble -> link -> patch carrier -> emit shave-kernels.inc; --prebuilt DIR is the KernelLib seam)",
    "llama.cpp/ggml/src/ggml-shave/tests/shave-selftest.cpp",
    "llama.cpp/ggml/src/ggml-shave/README.md",
    "llama.cpp/ggml/include/ggml-shave.h"
  ],
  "files_changed": [
    "llama.cpp/ggml/CMakeLists.txt (+ option(GGML_SHAVE ... OFF))",
    "llama.cpp/ggml/src/CMakeLists.txt (+ ggml_add_backend(SHAVE))",
    "llama.cpp/ggml/src/ggml-backend-reg.cpp (+ ggml-shave.h include and register_backend(ggml_backend_shave_reg()) under GGML_USE_SHAVE)"
  ],
  "handover_findings": [
    {
      "detail": "With PosixWorker's carrier (1x1024) and MY exact kernel `out[i] = (__fp16)((float)in[i] + (float)in[i ^ 256u])`, the delimiter is the toolchain invocation: the snapshot clang/assembler yields a 996 B ELF that writes nothing (constant 1.19e-07, 0/512 correct), while the LIVE toolchain root (moviCompile -> llvm-14 clang + live shave_asm.py, NO `; fmt=2`) yields a 1124 B ELF whose first half of every 512-element window is correct (1.5, 2.5, 3.5, 4.5 = a+b) and whose second half is not: 256/512 bit-exact. So the binary add and the XOR pairing both work on the wide carrier; what remains is the tile↔element mapping of the 4-target carrier (which the 2 invocations actually cover), not a compiler defect. Next step: read npunlock/build/fresh/npu-carrier/carrier-1x1024.inspect.json plus a 2-invocation probe, then set the per-tile packing accordingly; that unblocks a wide GGML_OP_ADD row.",
      "item": "Wide binary ADD is one packing step away, and the toolchain choice matters"
    },
    {
      "detail": "Even npunlock's own add1-fp16.c fixture assembles+links (1012 B) but executes as a copy with every assembler copy available, which is why my kernels are pinned in kernels/prebuilt/*.elf (delete that dir to compile from source). The wide template is unaffected.",
      "item": "Toolchain: narrow arithmetic kernels still regress"
    },
    {
      "detail": "gdb shows #0 common_params_fit_impl (common/fit.cpp). I fixed my half (device now reports 256 MiB/128 MiB instead of printing as 0 MiB) but the crash persists because the fit path divides by a zero bracket; I did not patch shared fit code.",
      "item": "`llama-cli -dev SHAVE0` SIGFPE is in llama.cpp's fit path, not my backend"
    }
  ],
  "model_result": {
    "command": "./build/bin/llama-cli -m ../models/gemma-4-E4B-it-Q4_0.gguf -p \"What is the capital of France?\" -n 32 -c 2048 -t 8 --no-warmup -v",
    "generation": "completes coherently; CPU-bound on the same path as the recorded CPU-only baseline (STATE.md: prompt 21.6 t/s, generation 8.3 t/s, 8 threads) because nothing is offloaded",
    "offloaded": "0 ops / 0 NPU invocations",
    "registration_proof": "common_param: device_info:   - SHAVE0  : Intel Meteor Lake NPU (NPU3720 SHAVE cores via npunlock)"
  },
  "not_claimed_and_why": {
    "GGML_OP_MUL / GGML_OP_SCALE": "no working fp32 register-register multiply encoding: `a*b` emits VAU.MUL.F32 rd, rb, ra and formats 0..3 x operand orders x destinations either leave rd unchanged or fault; hand-substituted SAU.MUL.F32 identical; padding sweeps never yield a*b. SUB likewise.",
    "SILU / GELU": "call path rejected by the snapshot clang; and vendor mlibm expf/tanhf cannot be bit-exact against the host libm the CPU backend uses. Addable on request with ULP tolerance.",
    "wide carriers": "PosixWorker's 1x1024/1x4096/1x16384 carriers generate and execute on Linux; my exact kernel now computes the correct binary add for the first half of every 512-element window under the live toolchain (see handover finding 1) - the remaining step is the tile↔element mapping, then one ENGINE_OPS row plus a selftest row."
  },
  "standalone_result": {
    "checks": [
      "supports_op(f16 ADD x16) true; tensors allocated in the SHAVE buffer type; SHAVE graph_compute success",
      "NPU result BIT-EXACT vs the CPU backend (16/16 f16)",
      "declined: f16 ADD x17, f16 ADD x4096, f32 ADD x16",
      "ggml_backend_sched: supported node bit-exact on the NPU; 4096-element node falls back to the CPU bit-exact",
      "GGML_SHAVE_STATS=1 emits a stable line with engine/invocations/offloaded/declined/unsupported/lanes/tile_elements/avg_invocation_us"
    ],
    "command": "./build/bin/ggml-shave-selftest",
    "exit": 0,
    "verdict": "PASS (NPU offloads: 2)"
  },
  "summary": "Delivered llama.cpp/ggml/src/ggml-shave/: a real, capability-gated ggml backend that offloads to the Meteor Lake NPU via npunlock's Level Zero engine and the native SHAVE toolchain. Standalone CPU-vs-NPU comparison is BIT-EXACT for f16 ADD over a 16-element tile (the only op the narrow carrier can execute today); the capability gate declines everything else and the scheduler fallback is proven bit-exact; llama-cli registers the backend as SHAVE0 and runs normally with 0 model ops offloaded; GGML_SHAVE=OFF builds and registers nothing. Final measurement: the wide (1x1024) binary add now computes correct values under the LIVE toolchain, leaving one tile-mapping step before a wide ADD row can be claimed.",
  "verified_carrier_contract": {
    "carrier": "npunlock/tests/fixtures/npu3720/abs-abs-1x32.blob: 1 f16 input 1x32 (64 B), 1 output 1x32, two chained ACT groups with 16-element tiles",
    "measured": "identity, a+b and x+1 compositions reproduce exactly on hardware; the unpatched carrier natively computes |x| (Abs); abs-add-1x16 pre-adds a fixed ramp r[i]=i/15-0.5 and is unusable",
    "mechanism": "patch ACT group0 with the op kernel and group1 with a copy kernel through the patchblob API (re-discovering targets between patches); lane i pairs with lane i^16, so the host packs [operand a | operand b] into one 32-element f16 tile"
  }
}