{
  "status": "hard blocker reached; measurement deliverables handed over (gate still RED)",
  "gate": {
    "smoke": "cd npunlock && ./tools/npu_add1_smoke.sh --elf <ours> -> rc=1, oracle failed; our kernel writes zero bytes (base/V1/V2/V3/v30 variants, every run this session); gold-verbatim control PASSES rc=0 (2x)",
    "assembler_leagalizer_note": "shave_asm now auto-inserts 6 delay-slot fillers ('legalize: 6 delay slot(s) filled'); hand-padded kernels therefore get double padding — all post-fix measurements used either no manual fillers or high scratch registers (i20+)"
  },
  "measurements_delivered": {
    "load_latency": "K_min = 6 slots (K=4,5 FAIL; K=6,7,12 PASS). Filler type free (BRU.NOP 0x07, IAU, CMU). Counts instructions/slots, not packets. Byte alignment irrelevant (shifting the load by 1-4 bytes still passes).",
    "branch_delay": "exactly 6 instructions execute after a taken branch (m4 marker chain: last value = 4*i8 = 3rd of 8 (IAU.ADD;ST.32) pairs)",
    "out_pointer": "params+0x28 IS the output pointer: padded `LDO i0,i18,0x28` + 6 fillers then `LSU1.ST.32 i0,i0` lands 0x2E014000 (invocation 1) / 0x2E014010 (invocation 2) in the oracle window (k1, 2-3x). The c2-class read and the STI/ST.32 store forms are correct; no 01-class/descriptor byte is needed.",
    "working_recipes": [
      "k1: padded read of +0x28 + LSU1.ST.32 -> pointer visible",
      "k3b: padded read-out / read-in / LD.32.F16.F32 / STI.16.F32.F16 -> writes land"
    ],
    "runtime_values": {
      "rank": 4,
      "dims_pointer_params_plus_0x10": "0x80000050 (= params base + 0x50, the dims values region)",
      "params_pointer": "~0x80000000"
    },
    "guard_model": "CMU.CMx.I32 <a>,<b> does NOT write its operand register (G7: rank=4 -> CMU.CMII.U32 i1,i2(14) -> 6 fillers -> ST.32 i1 reads back 4; G8: CMU.CMZ.I32 i1 -> same; 3/3 each). It sets a flag; `BRU.BRA <reg>,tgt` is the consumer (gold: CMU.CMZ.I32 i5 @0x50 -> BRU.BRA i5 @0x53). Our XOR-based guard lowering therefore branches on a register the CMU never touched — the likely original cause of our kernel never reaching its store. Backend fix handed to MedicalCrayfish: branch directly on the CMU flag (choose the CMU condition for the wanted sense), drop the XOR/0-1 materialisation.",
    "unproven_primitive": "what `BRU.BRA <reg>` tests (GPR zero/non-zero vs the CMU flag): T_false/T_true (i1=4/20, both non-zero) both skipped the witness (consistent with branch-on-non-zero-GPR); B0/B1 (i1=0/1) were polluted by the minimal-kernel LDIL artifact. Must be measured inside the backend-built kernel using params fields as constants (params+0x8 = 1, params+0xc = rank = 4)."
  },
  "open_items_and_next_steps": [
    "Measure the branch-condition primitive inside the real kernel (params constants, not LDIL) — it gates every guard/loop reshape.",
    "MedicalCrayfish's shipped kernel now executes and writes exactly one 16-bit element per invocation; their count ends up 0 because the dims-loop `dim` value misbehaves. I measured the dims pointer as deterministic (0x80000050) but the dependent dims LOADS as run-varying in minimal kernels (DV/DV2/DV3, 3 runs each) — the load path through the dims pointer is the next thing to measure from inside the real kernel.",
    "Then re-check the oracle with the 6/6 latency rules in place; the store/read encodings themselves are proven correct."
  ],
  "artifacts": [
    "llvm-14/BYTE_EXACT_LOG.md — iterations 20, 20b, 20c, 21, 21b, 21c, 22, 23, 23b, 23c, 23d, 23e (trusted methods; gold-splice matrix; S3 NOP matrix; the two latency constants; the guard/CMU model; assembler calibration; loop-shape and dims-value raw results; ctest record). A sibling (MedicalCrayfish) also appended their iteration 24 (backend delay-slot pass + current kernel state) to the same file.",
    "llvm-14/tmpdump/mkapp.py, llvm-14/tmpdump/mkpatch.py — gold-prefix composite builder and size-preserving gold byte-patcher",
    "llvm-14/tmpdump/oracle_isolate/ (~295 .s kernels: G1..G8, T_*/B*, k1..k9, m1..m4, pa..pd/pb1..pb4, L0/L0b, DV/DV2/DV3, padall/fullpad*/wit_a/fp2/fp3/fp_nog*/fp_nogB, S3 r01..r20, a1_*/a2_*, lr*/wq*/e_i8/e_i9)"
  ],
  "ctest_record": {
    "cmd": "cd npunlock/build/gated-check && NPUNLOCK_SHAVE_TOOLCHAIN_DIR=…/shave-toolchain-root ctest -R shave_add1 --output-on-failure",
    "result": "***Failed — 'linked ELF differs from the retained repeatable build' (byte-compare class; offline suite otherwise 15/15 green)"
  }
}