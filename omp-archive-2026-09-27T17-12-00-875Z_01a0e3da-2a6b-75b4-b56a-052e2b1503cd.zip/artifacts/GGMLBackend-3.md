{
  "acceptance": {
    "ggml_shave_OFF_unchanged": "PASS - a fresh -DGGML_SHAVE=OFF configure contains no ggml-shave target and no GGML_USE_SHAVE define; `make ggml` succeeded there and `nm -D libggml.so | grep shave` = 0 symbols.",
    "llama_cli_dev_SHAVE0": "PASS - exits 0 with the default fit path and with --fit off (`-p 'The capital of France is' -n 16 --temp 0 -st` -> 'Paris'); the 254 s I first measured was the interactive REPL waiting on stdin, not the fit.",
    "model_run_nonzero_verified_offload": "PASS - 1222..1982 NPU invocations in short runs, every one serving a real f32 ADD/MUL node, generated text identical to the CPU-only run.",
    "selftest": "PASS - 55 x [ok], 0 FAIL, 'ggml-shave: PASS (NPU offloads: 15)' (ggmlback-3/work/selftest_final.log sha256 922a28cb...)"
  },
  "cleanup_and_scratch": {
    "background_jobs": "the two superseded jobs (an old OFF configure attempt and a duplicate census rerun) were cancelled; the census rerun was still driving a llama-cli on the NPU, so killing it also freed the device for EvalHarness-2's frozen pass.",
    "scratch_policy": "all builds used disk-backed TMPDIR=/home/asdf/tmpbuild (ext4), never /tmp; every durable artifact is under /home/asdf/projects/npunlock-work/{llama.cpp/ggml/src/ggml-shave,ggmlback-3}; the only remaining llama-cli processes are EvalHarness-2's eval harness runs.",
    "scratch_usage": "ggmlback-3/work is 2.8 MB and holds the evidence files listed below (transient probe binaries deleted after the cases passed)."
  },
  "coordination": [
    "EvalHarness-2: build/bin frozen for their 8-prompt NPU pass; told them the exact library hash and the denormal caveat to attribute any numeric divergence to.",
    "CorpusWave2: filed the fp16 dropped-store repro + the f32-carrier contract failure; they root-caused the store as a missing aliased-store pad slot (FINDINGS.md).",
    "PosixWorker: confirmed the carrier windowing rule and the FP16-only contract boundary; their two-input carrier recommendation matches what shipped.",
    "GGMLBackend-4: handed off the batching caveat (dependent nodes inside one split make naive batching incorrect) and my engine shape."
  ],
  "evidence_files": {
    "census.txt": "sha256 5a76ca2be91d2097b7cb0ad90f181126c18f29ce3d872c1574b1dcf241686d43",
    "err_SHAVE0.txt": "sha256 9a17a6e464ad3263fff18f66b6025ee923871481e7d1111e647152aab9f4e349",
    "selftest_final.log": "sha256 922a28cbb33794894a76ae83d5910f23f1cb308887fff1a6ddbf3b305b9cad20",
    "text_equality_pair": "out_SHAVE0.txt fb250a57... vs out_none.txt 26221193..."
  },
  "invariants": {
    "fit_cpp_guard": "common/fit.cpp +10 lines: `if (mem_high[id] == mem[id]) break;` before both false-position divisions (lines 694 and 772); shared llama.cpp code, no other change.",
    "no_fmt_fixup": "the obsolete uniform `; fmt=2` asm rewrite is gone; the live toolchain emits the register form itself and build_kernels.py hard-fails on a toolchain-snapshot path."
  }
}