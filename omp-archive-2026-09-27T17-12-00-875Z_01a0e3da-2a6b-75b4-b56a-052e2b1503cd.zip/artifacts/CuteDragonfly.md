{
  "verdict": "complete",
  "acceptance": {
    "npureport": "NPU_REPORT.md contains a real report from this machine: all seven stages passed (loader, device_selection, graph_extension, graph_create, initialization, execution, oracle) with byte-exact host-oracle match and probe exit 0; both the initial oracle-failed report and the final passing report are pasted with diagnosis",
    "patchblob_cli": "npunlock-patchblob exists (src/npunlock_patchblob/main.c), registered in CMake for all platforms, installed, -Wall -Wextra -Werror -Wpedantic clean; offline ctest patchblob_cli_golden green: patching gold add1-fp16.elf into abs-add-1x16-tile1.blob reproduces committed add1-shared-1x16.blob byte-for-byte (sha256 2010915f2d21e07d2afee613ffe8f38a9ce6e39523ab98e0762c1bd40e04d95f)",
    "smoke": "tools/npu_add1_smoke.sh --elf gold exits 0 end-to-end (patch+gold cmp, bundle create/verify, probe, report assertions); nonzero on failures (exit 1 bad ELF, exit 2 missing args); optional --toolchain-dir shavecc step implemented and skips cleanly; no wine/network",
    "ctest": "default ctest 15/15 green, output pasted into BUILD_REPORT.md section 7"
  },
  "key_finding": "The bundle's original fp16_add1_exact oracle (expected=input+1) is wrong for the abs-add carrier. True graph semantics: output = binary16(binary16(x + r) + 1) with r[i]=binary16(i/15-0.5), a ramp the carrier stores outside the two patched ACT code ranges (constants at file offset 39820, first value -0.5f). Unpatched carrier computes |x+r|. The corrected oracle reproduces byte-exactly: (1) committed Windows expected_fp16 in tests/integration/test_graphinfer.c for a different input, (2) this machine's observed output, (3) unpatched carrier output. Conclusion: Linux NPU executed the patched SHAVE ELF correctly; first-run oracle failure was a model bug, not hardware.",
  "changes": [
    "tools/porting_probe.py: oracle corrected to fp16_carrier_add1_exact (create+verify+manifest purpose)",
    "src/npunlock_patchblob/main.c: new CLI --graph/--elf/--output/--report, self-discovering targets, confirmed alignment 0x400/tail 0x80",
    "CMakeLists.txt: npunlock_patchblob target (portable), install(), format sources, new ctest",
    "cmake/patchblob_cli_golden_test.cmake: patch + byte-compare + report-schema check",
    "tools/npu_add1_smoke.sh: end-to-end script (optional shavecc byte-exact compile via python NativeLibraries.compile_shave when --toolchain-dir given)",
    "NPU_REPORT.md: new (reports, stage table, hashes, environment, oracle diagnosis, reproduction, limits)",
    "BUILD_REPORT.md: appended section 7 with 15/15 ctest output",
    "wiki/PORTING_PROBE_BUNDLE.md, wiki/PORTING.md, wiki/DEVELOPMENT.md, wiki/LIMITATIONS.md, README.md: stale Linux-execution and oracle claims corrected; npunlock-patchblob documented"
  ],
  "environment": "Linux 7.0.0-34-generic x86_64; Intel Meteor Lake NPU PCI 8086:7d1d at 00:0b.0; /dev/accel0 root:render (user in render); intel-level-zero-npu / intel-driver-compiler-npu / intel-fw-npu 1.38.0.20260910-34487311128; probe-reported driver_version 1789049548 (0x6aa2bacc), vendor 0x8086, device 0x7d1d; no ZE_* env overrides needed",
  "artifacts": {
    "execution_report": "build/add1-linux-report.json (all passed), also build/fresh/npu-smoke/execution-report.json",
    "patch_report": "npunlock.patchblob.v1 with input/ELF/output sha256s",
    "bundle": "build/add1-probe (4 files, manifest oracle fp16_carrier_add1_exact)"
  },
  "limits": "One graph, one device, one driver stack; in-process probe with finite fence wait; ir2blob graph compilation remains Windows-only; --toolchain-dir mode not exercised today (ToolchainBuild's toolchain root not yet available) - code path present and skip path verified"
}