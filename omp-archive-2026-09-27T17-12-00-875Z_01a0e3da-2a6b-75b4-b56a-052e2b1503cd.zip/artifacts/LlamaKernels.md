{
  "status": "complete",
  "deliverable": "6 new llama.cpp/ggml workload kernels + 4 mlibm sidecars + harness evidence",
  "files_authored": {
    "new_kernels": [
      {
        "path": "corpus/kernels/l01_silu_f32.c",
        "provenance": "llama/vec.h:1046 ggml_silu_f32 (wrapper llama/vec.cpp:412 ggml_vec_silu_f32); lib mlibm (expf)",
        "sidecar": "l01_silu_f32.opts LINKLIB=mlibm"
      },
      {
        "path": "corpus/kernels/l02_rms_norm_f32.c",
        "provenance": "llama/ops.cpp:3924 ggml_compute_forward_rms_norm_f32 + llama/vec.h:703 ggml_vec_scale_f32; lib mlibm (sqrtf)",
        "sidecar": "l02_rms_norm_f32.opts LINKLIB=mlibm"
      },
      {
        "path": "corpus/kernels/l03_softmax_f32.c",
        "provenance": "llama/ops.cpp:5584 ggml_compute_forward_soft_max_f32 + vec.h:1541 ggml_vec_max_f32 + vec.cpp:531 ggml_vec_soft_max_f32 + vec.h:703 ggml_vec_scale_f32; lib mlibm (expf)",
        "sidecar": "l03_softmax_f32.opts LINKLIB=mlibm"
      },
      {
        "path": "corpus/kernels/l04_vec_dot_f32.c",
        "provenance": "llama/vec.cpp:11 ggml_vec_dot_f32 (scalar reference); no libm",
        "sidecar": "none (no opts needed)"
      },
      {
        "path": "corpus/kernels/l05_rope_f32.c",
        "provenance": "llama/ops.cpp:5958 rope_yarn + 5975 ggml_rope_cache_init + 6062 rotate_pairs<float> + 6082 ggml_compute_forward_rope_flt<float> (NEOX); lib mlibm (sinf, cosf, powf)",
        "sidecar": "l05_rope_f32.opts LINKLIB=mlibm"
      },
      {
        "path": "corpus/kernels/l06_scale_f32.c",
        "provenance": "llama/vec.h:703 ggml_vec_scale_f32 (y = a*x); no libm",
        "sidecar": "none (no opts needed)"
      }
    ],
    "notice": "Each file carries the provenance line plus the full MIT License text (Copyright (c) 2023-2026 The ggml authors) reproduced from corpus/llama/LICENSE.",
    "no_other_files_touched": "Only corpus/kernels/l*.c and l*.opts were created. llvm-14, shave-isa and all pre-existing corpus files untouched.",
    "harness_command": "cd /home/asdf/projects/npunlock-work/corpus && bash run_corpus.sh --only 'l01_silu_f32,l02_rms_norm_f32,l03_softmax_f32,l04_vec_dot_f32,l05_rope_f32,l06_scale_f32' --tag llamakernels",
    "harness_note": "Ran with the private tag `llamakernels` (permitted by run_corpus.sh --tag) so no shared results.tsv or log path collides with a concurrent agent. Artifacts: corpus/results_llamakernels.tsv, corpus/logs/llamakernels.<name>.{compile,asm,link}.err, corpus/build/llamakernels.<name>.{s,o,elf}, corpus/logs/llamakernels.toolchain.txt (stamp: run 2026-09-28T14:03:51-05:00; shave_asm.py parses; sha256 of moviCompile/moviAsm/moviLLD/shave_asm.py/encodings.json recorded there).",
    "results": [
      {
        "kernel": "l01_silu_f32",
        "compile": "FAIL(rc=1)",
        "asm": "-",
        "link": "-",
        "validate": "SKIP",
        "text_bytes": null,
        "class": "error",
        "first_error": "fatal error: error in backend: SHAVE: calls are unsupported in wave 1 (callee ExternalSymbol); see TARGET_NOTES.md",
        "gap": "1 calls (LowerCall) — exercised as intended. clang IR is `declare float @llvm.exp.f32`; the DAG legalizer expands it via LegalizeDAG.cpp:4011 `case ISD::FEXP: ExpandFPLibCall(Node, RTLIB::EXP_F32, ...)`, so the final callee is the mlibm symbol `expf` [INFERENCE: the fatal message only names ExternalSymbol; mlibm.a defines both `expf` (T) and `__exps` (T)]."
      },
      {
        "kernel": "l02_rms_norm_f32",
        "compile": "FAIL(rc=70)",
        "asm": "-",
        "link": "-",
        "validate": "SKIP",
        "text_bytes": null,
        "class": "ISEL-CannotSelect",
        "first_error": "fatal error: error in backend: Cannot select: t11: f32 = uint_to_fp t10\n  t10: i32,ch = CopyFromReg t0, Register:i32 %12\nIn function: controlled_act",
        "gap": "2 int<->float (int_to_fp), hit BEFORE the sqrtf node. Origin: the verbatim `const float mean = sum/ne00;` converts the unsigned row length ne00 to f32. Isolated probe `float g(float s, unsigned n){return s/n;}` => `Cannot select: t3: f32 = uint_to_fp Register:i32 $r19`; `float f(float s, int n){return s/n;}` => `Cannot select: t3: f32 = sint_to_fp ...` (both unselectable today). sqrtf is the next blocker: probe `float a(float x){return sqrtf(x);}` => `Cannot select: t2: f32 = fsqrt Register:f32 $r18`."
      },
      {
        "kernel": "l03_softmax_f32",
        "compile": "FAIL(rc=1)",
        "asm": "-",
        "link": "-",
        "validate": "SKIP",
        "text_bytes": null,
        "class": "error",
        "first_error": "fatal error: error in backend: SHAVE: only i32 value-selects are supported in wave 1; see TARGET_NOTES.md",
        "gap": "6 fp compares / f32 value-select, hit BEFORE the expf call. Origin: verbatim ggml max-reduce `max = MAX(max, x[i])` (MAX(a,b) = a>b?a:b, ggml-impl.h) produces an f32 ISD::SELECT; SHAVEISelLowering.cpp:98 already marks ISD::SELECT MVT::f32 Expand, and its custom inserter only handles i32 selects. expf (calls gap) is also present but not reached first."
      },
      {
        "kernel": "l04_vec_dot_f32",
        "compile": "OK(rc=0)",
        "asm": "OK(rc=0)",
        "link": "OK(rc=0)",
        "validate": "OK",
        "text_bytes": 496,
        "class": "PASS",
        "first_error": null,
        "gap": "none; two-record input + third-record output ABI works. Emitted SHAVE asm loads record offsets 0x28 (input 1) and 0x50 (output record 2) => ACT_ABI_TENSOR_RECORD_BYTES=0x28 confirmed on hardware-shape code. build/llamakernels.l04_vec_dot_f32.elf (1124 B) passes validate_elf.py."
      },
      {
        "kernel": "l05_rope_f32",
        "compile": "FAIL(rc=70)",
        "asm": "-",
        "link": "-",
        "validate": "SKIP",
        "text_bytes": null,
        "class": "ISEL-CannotSelect",
        "first_error": "fatal error: error in backend: Cannot select: t7: f32 = fpow t26, t5\n  t26: f32,ch = load<(load (s32) from constant-pool)> t0, ConstantPool:i32<float 1.000000e+04> 0, undef:i32\n  t5: f32 = fdiv t28, t3\n  t3: f32 = sint_to_fp t2\nIn function: controlled_act",
        "gap": "5 builtins (ISD node missing) + 2 int<->float. Origin: verbatim header constant `theta_scale = powf(freq_base, -2.0f/n_dims)` -> fpow (and sint_to_fp for n_dims); the rotate loop then needs fsin/fcos."
      },
      {
        "kernel": "l06_scale_f32",
        "compile": "OK(rc=0)",
        "asm": "OK(rc=0)",
        "link": "OK(rc=0)",
        "validate": "OK",
        "text_bytes": 480,
        "class": "PASS",
        "first_error": null,
        "gap": "none; scalar-in-second-record + output-in-third-record ABI works. build/llamakernels.l06_scale_f32.elf (1108 B) passes validate_elf.py."
      }
    ],
    "summary_counts": {
      "kernel_count": 6,
      "compile_ok": 2,
      "assemble_ok": 2,
      "link_ok": 2,
      "validate_ok": 2,
      "fail": 4
    },
    "key_finding_premise_correction": {
      "claim_in_assignment": "'expf/sqrtf/sinf/cosf exercise the CALLS gap'",
      "measured": "Only expf is a libcall today. sqrtf/sinf/cosf/powf are folded by clang into the LLVM intrinsics fsqrt/fsin/fcos/fpow, which the SHAVE backend has NO handling for at all, so they fail in ISel ('Cannot select: f32 = fsqrt|fsin|fcos|fpow'), i.e. the BUILTINS gap (#5), not LowerCall.",
      "isolation_probes": [
        "float a(float x){return sqrtf(x);} -> fatal error: Cannot select: t2: f32 = fsqrt Register:f32 $r18",
        "float b(float x){return sinf(x)+cosf(x);} -> fatal error: Cannot select: t2: f32 = fsin Register:f32 $r18",
        "float c(float x){return cosf(x);} -> fatal error: Cannot select: t2: f32 = fcos Register:f32 $r18",
        "float c(float x,float y){return powf(x,y);} -> fatal error: Cannot select: t3: f32 = fpow Register:f32 $r18, Register:f32 $r19",
        "float g(float x){return x/(1.0f+expf(-x));} -> IR `declare float @llvm.exp.f32`; backend: SHAVE: calls are unsupported in wave 1 (callee ExternalSymbol)"
      ],
      "backend_evidence": "`grep -rniE 'fsqrt|fsin|fcos|fpow|sqrtf|sinf|cosf|powf|expf' llvm/lib/Target/SHAVE` returns ZERO matches, and SHAVEISelLowering.cpp's setOperationAction list (lines 75-127) contains no FSQRT/FSIN/FCOS/FPOW entry, so those nodes survive to ISel.",
      "suggested_fix_direction": "LegalizeDAG.cpp:3965-3991 already expands ISD::FSQRT/FSIN/FCOS via ExpandFPLibCall(RTLIB::SQRT_F32/SIN_F32/COS_F32) and :4093-4096 ISD::FPOW via RTLIB::POW_F32; RTLIB libcall names are the flat C names (`sqrtf`,`sinf`,`cosf`,`powf`), all present in mlibm.a. So `setOperationAction(ISD::FSQRT|ISD::FSIN|ISD::FCOS|ISD::FPOW, MVT::f32, Expand)` in the SHAVETargetLowering constructor converts them into ordinary LowerCall sites and the in-flight calls work covers them. Pointed out for the writer; I did not edit llvm-14."
    },
    "documented_deviations_in_kernels": [
      "float accumulators instead of ggml_float (=double): `nm mlibm.a` shows no fp64 soft-float helpers at all (no __adddf3/__subdf3/__muldf3/__divdf3/__extendsfdf2/__floatsidf/__fixdfsi; it does reference __truncdfsf2/strtof/__fixsfdi, which the header's MLIBM_DEFINE_LINK_COMPAT stubs supply). A double accumulator would therefore add an unlinkable soft-float gap unrelated to the CLOS/calls work, so l02/l03/l04 use the float accumulator (which is also ggml's own SIMD-path accumulation form, vec.cpp `float sumf = 0.0f`). Noted in each file header.",
      "l02 pins eps = 1e-5f (llama hparams.f_norm_rms_eps) because the ACT invocation record carries no op_params; l05 pins freq_base=10000.0f, freq_scale=1.0f, ext_factor=0.0f, attn_factor/mscale=1.0f, sin_sign=+1.0f, mode=NEOX, n_dims=ne0 for the same reason (with ext_factor==0 the rope_yarn ramp term is exactly zero); l06 takes its runtime scale v from input record 1 and l05 takes pos[] from input record 1.",
      "No <math.h> is reachable: /home/asdf/projects/llvm-14/build/lib/clang/14.0.6/include has float.h/stddef.h/stdint.h but no math.h, and /usr/include/math.h aborts with 'unsupported machine mode __TC__' (/usr/include/bits/floatn.h:83). Therefore each kernel declares the mlibm entry points explicitly (`float expf(float);` etc.). This is a corpus-wide constraint: any future realistic C kernel must declare libm prototypes or ship a minimal math.h in corpus/include.",
      "Infinity in l03 comes from `#define INFINITY (__builtin_inff())` (no math.h)."
    ],
    "what_i_could_not_establish": [
      "Link-time behavior of the mlibm paths (l01/l02/l03/l05): those kernels never reach link, so I could not verify that MLIBM_DEFINE_LINK_COMPAT's strtof/__truncdfsf2/__fixsfdi stubs are sufficient closure for the expf/sqrtf/sinf/cosf/powf objects, nor whether the exact callee is `expf` vs `__exps`.",
      "No numeric/functional oracle: the harness only compiles/assembles/links/validates a structural ELF contract; none of the six kernels was executed on hardware or in an emulator, so per-kernel semantics (e.g. rope theta ordering, softmax normalisation) are source-faithful but not runtime-verified.",
      "Whether SHAVE has any ld/st unit constraints affecting these kernels at scale (my loads/stores all use the existing LSU rewrite path; no failure or warning beyond the reported classes appeared for l04/l06).",
      "The exact OperationAction currently applied to FSQRT/FSIN/FCOS/FPOW for MVT::f32 (not listed in SHAVEISelLowering.cpp:75-127, so it is the base-class default; I only measured that they reach ISel unexpanded)."
    ]
  }
}