{
  "final": true,
  "status": "complete",
  "one_line": "All four vendor-RE items closed with repeated hardware evidence; the by-products (compressed-NOP filler encoding, branch marker+fill semantics, an obj-path encoder corruption, and pattern-dependent LSU trap legality) were each routed to the owning agent and are recorded in the deliverable docs.",
  "deliverables": {
    "packets/PACKET_SPEC.md": "688 lines: §8 compressed-NOP filler table, §9 branch marker+fill (incl. §9 gold descriptor table), §10 class byte, §11 full gold 0x00-0xbf byte map, §12 emission recipe + §12.1 effective descriptor, §13 obj-path bug, §14 pattern-dependent LSU traps + §14.1 store-field measurements",
    "packets/VERIFIED_EXAMPLES.md": "532 lines, Example K (probe sources, byte strings, verdicts)",
    "packets/probes/ROUND2_LOG.txt": "72-line condensed evidence log",
    "packets/probes/**": "180+ new probe sources",
    "packets/tools/{runp3raw.sh,defdec.py}": "repro harness + def-based stream decoder"
  },
  "answers": {
    "filler_table": "ONE byte = (n-1)<<4 (low nibble 0) covers exactly n issue slots: 1=0x00 2=0x10 3=0x20 4=0x30 5=0x40 6=0x50 7=0x60 8=0x70 9=0x80 10=0x90 11=0xa0 12=0xb0 13=0xc0 14=0xd0 15=0xe0 16=0xf0. Measured: n=1..5 fail the 6-slot load gate, n=6 passes, n>=7 passes; counts add; low nibble != 0 is not a NOP; BRU.NOP 0x07 = 1 slot (vendor uses it only for single slots / compression-off). Vendor evidence: +0x5c = (n-1)*16 in FUN_18005b9e0:57169, FUN_18005f070:59801, FUN_18005be70:57412; printer FUN_1800642d0:63160 decodes ((f>>4)&0xf)+1.",
    "branch_descriptor": "BRU.BRA (4B: b5 disp16 flag) + REQUIRED marker + compressed NOP of (6-k) slots, k = real delay instructions (1b 20 -> 3, 1b 40 -> 1, 1b 50/60/f0 -> 0). No marker => device fault. Gold: 1b 40, 2b 40, 1b 50 (forward), eb 30, eb+07 (backward). Not-taken path unaffected.",
    "class_byte": "Semantics unresolved; keep emitting c2 (the only CV3600xx table opcode for LSU0.LDO.32 = 0x2c2); gold's 01 faults in isolation; mechanism = slot-descriptor machinery.",
    "gold_map": "PACKET_SPEC.md §11: all five branches decode exactly; compressed NOPs + markers explain all previously undecoded bytes; still open 0x0b-0x49, 0x79-0x7c, 0x7e-0x7f, 0x8a-0x8c; 0x42-family is 28/32-bit only.",
    "pipe_recipe": "<=3 ops / <=128 bits / <=1 op per unit; flat==packed; LSU0 loads / LSU1 stores; >=6 slots writer->consumer; branch = BRU.BRA + marker + (6-k)-slot fill."
  },
  "by_products_routed": [
    "obj-path bit-31 corruption for AU immediates (my repro; fixed upstream, gates 180/180)",
    "effective descriptor semantics k=1 for our toolchain's 1b+40 pair",
    "pattern-dependent LSU trap legality (register x immediate x form) with the store-field data they requested",
    "0x42-family has no 24-bit form (answers AsmSchedImpl's LDXV question)"
  ],
  "repro": "OUT=/tmp/pkr bash packets/tools/runp3raw.sh packets/probes/q_50.s (PASS) / q_40.s (FAULT) / br/t_none.s (FAULT) / br/t_1b40.s (TAKEN) / br/dc_1b40.s (02 00 00 00) / br/p25.s (40 43 01 2e) / br/li19.s (FAULT) / br/lim21.s (ok). Use runp3raw.sh, never runp3.sh, for filler work (the latter auto-legalizes).",
  "caveats": [
    "Verdicts repeated 2-3x; one outlier under concurrent device load documented.",
    "Sibling appends landed in the shared docs during the session; my sections were verified present at the end.",
    "The trap set is presented as measured pattern legality, not a derived ISA rule."
  ]
}